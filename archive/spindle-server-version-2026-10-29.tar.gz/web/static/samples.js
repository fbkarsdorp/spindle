// Short retellings of well-known tales, used as samples on the reading page.

export const SAMPLES = [
  {
    title: 'Hansel and Gretel',
    text: `At the edge of a great forest lived a poor woodcutter with his two children and their stepmother. When famine came, the stepmother persuaded him to lead the children deep into the woods and leave them there. The first time, the boy dropped white pebbles along the path, and by moonlight they followed them home. The second time he could only scatter crumbs of bread, and the birds of the forest ate every one.

Lost and hungry, the children came upon a little house built of bread, with a roof of cake and windows of clear sugar. An old woman hobbled out and took them in kindly, but she was a witch who lay in wait for children in order to eat them. She shut the boy in a stable to fatten him, and every morning made him stretch out his finger; he held out a little bone instead, and her red eyes could not see the difference.

At last she lost patience and heated the oven. "Creep in," she told the girl, "and see whether it is hot enough." The girl pretended she did not know how, and when the witch put her own head in to show her, the girl pushed her inside and bolted the iron door. The children filled their pockets with the witch's pearls and jewels, a white duck carried them across the water, and they found their way home to their father.`,
  },
  {
    title: 'The Frog King',
    text: `In olden times, when wishing still helped, there lived a king whose youngest daughter was so beautiful that the sun itself marvelled whenever it shone on her face. Her favourite plaything was a golden ball, and one day it rolled away from her and fell into a deep well.

As she wept, a frog put its thick ugly head out of the water and promised to fetch the ball if she would let him be her companion, eat from her little golden plate and sleep in her little bed. She promised everything, thinking a frog could never leave the water, and ran home as soon as she had her ball.

The next day the frog came knocking at the palace door, and the king told his daughter that what she had promised she must perform. She carried the frog upstairs with two fingers, but when he asked to be lifted into her bed she flew into a rage and threw him with all her strength against the wall. When he fell down he was no longer a frog but a king's son with kind and beautiful eyes, who told her that a wicked witch had bewitched him and that she alone could have released him.`,
  },
  {
    title: 'The Cyclops',
    text: `Sailing home from the war, the hero and twelve companions entered a cave on an island of giants and feasted on the cheeses they found there. In the evening the owner drove in his flocks: a giant with a single eye in the middle of his forehead, who rolled a huge stone across the entrance and devoured two of the men for his supper.

The hero gave him strong wine, and when the giant asked his name he answered, "My name is Nobody." While the giant lay in a drunken sleep, the men heated the point of an olive stake in the fire and drove it into his eye. His neighbours came running at his cries, but when he shouted that Nobody was killing him, they went away again.

In the morning the blinded giant sat at the door of the cave and felt the backs of his sheep as they went out to pasture. But the hero had tied each of his men beneath the bellies of three rams, and clung himself to the fleece under the largest ram of all, and so they escaped to their ship.`,
  },
  {
    title: 'Urashima Tarō',
    text: `A young fisherman saw children tormenting a turtle on the beach, bought it from them and let it go into the sea. Some days later the turtle came back and carried him on its back beneath the waves to the Dragon Palace, where the daughter of the sea king thanked him for his kindness and became his wife.

After what seemed three years he longed to see his parents again. The princess gave him a lacquered box as a parting gift, but warned him that he must never open it. When he came ashore his village was gone and nobody knew his name; an old man told him that a fisherman of that name had been lost at sea three hundred years before.

In his grief Urashima forgot the warning and lifted the lid. A wisp of white smoke rose from the box, and at once his hair turned white, his face wrinkled, and he fell dead upon the shore.`,
  },
  {
    title: 'Orpheus',
    text: `The singer's young wife was bitten by a snake and died, and in his grief he went down into the underworld itself. With his lyre he sang so sweetly that the ferryman carried him across, the three-headed dog let him pass, and the king and queen of the dead were moved to tears.

They granted that his wife might follow him back to the world of the living, on one condition: he must not look back at her until they had both come out into the light. They climbed the steep dark path in silence. At the very threshold, uncertain whether she was still behind him, he turned to look, and she slipped back into the shadows and was lost to him for ever.`,
  },
];
