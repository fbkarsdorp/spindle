// Spindle — front end. Plain ES modules, no build step.

import { SAMPLES } from './samples.js';

const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const main = $('#main');

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (n) => Number(n).toLocaleString('en-GB');
const trimDot = (s) => String(s || '').replace(/\.$/, '');

const LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXZ'.split('');
const CAT_COLORS = {
  A: '#b8432f', B: '#5d7f3a', C: '#7b4a8e', D: '#2f5d8a', E: '#6f6a64', F: '#c08a2b', G: '#8a3b2a', H: '#3d8a84',
  J: '#9c6b3a', K: '#d0662f', L: '#4f6fa8', M: '#8c5f99', N: '#8f8f34', P: '#b39040', Q: '#2e7a5a', R: '#6a4e3b',
  S: '#a33b5c', T: '#cf6c86', U: '#5b8fa8', V: '#7d6aa8', W: '#4c7a3a', X: '#d79a2a', Z: '#857c55',
};

const SHORT = {
  A: 'Mythological', B: 'Animals', C: 'Tabu', D: 'Magic', E: 'The dead', F: 'Marvels', G: 'Ogres', H: 'Tests',
  J: 'Wise & foolish', K: 'Deceptions', L: 'Reversals', M: 'Fate ordained', N: 'Chance & fate', P: 'Society',
  Q: 'Rewards', R: 'Captives', S: 'Cruelty', T: 'Sex', U: 'Nature of life', V: 'Religion', W: 'Character',
  X: 'Humor', Z: 'Miscellany',
};

// ------------------------------------------------------------------ api

async function getJSON(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
  return r.json();
}
async function postJSON(url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
  return r;
}
let META = null;
const meta = async () => (META ??= await getJSON('/api/meta'));

// ------------------------------------------------------------------ art

const artCache = new Map();
function art(name) {
  if (!artCache.has(name)) {
    artCache.set(name, fetch(`/art/${name}.svg`).then((r) => (r.ok ? r.text() : '')).catch(() => ''));
  }
  return artCache.get(name);
}
async function hydrateArt(root = document) {
  await Promise.all($$('[data-art]:not([data-hydrated])', root).map(async (el) => {
    el.dataset.hydrated = '1';
    const svg = await art(el.dataset.art);
    el.innerHTML = svg.replace(/<\?xml[^>]*>/, '');
    const s = el.querySelector('svg');
    if (s) { s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false'); }
  }));
}
const artEl = (name, cls = '') => `<span class="${cls}" data-art="${name}"></span>`;
const whorl = (cls = 'whorl') => artEl('spindle', cls);

// ------------------------------------------------------------- toasts

let toastTimer;
function toast(msg) {
  const t = $('.toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

// ---------------------------------------------------------------- router

const routes = [
  [/^\/$/, viewHome],
  [/^\/search\/?$/, viewSearch],
  [/^\/read\/?$/, viewRead],
  [/^\/motif\/(.+)$/, viewMotif],
  [/^\/browse\/?$/, viewBrowse],
  [/^\/browse\/(.+)$/, viewBrowse],
  [/^\/map\/?$/, viewMap],
  [/^\/about\/?$/, viewAbout],
];
let cleanup = null;

function navigate(url, { replace = false } = {}) {
  if (replace) history.replaceState({}, '', url);
  else history.pushState({}, '', url);
  render();
}

async function render() {
  const { pathname } = location;
  if (cleanup) { cleanup(); cleanup = null; }
  for (const [re, view] of routes) {
    const m = pathname.match(re);
    if (m) {
      const section = pathname.split('/')[1] || 'home';
      $$('.nav a').forEach((a) => {
        if (a.dataset.nav === section) a.setAttribute('aria-current', 'page');
        else a.removeAttribute('aria-current');
      });
      try {
        cleanup = (await view(...m.slice(1).map(decodeURIComponent))) || null;
      } catch (err) {
        console.error(err);
        main.innerHTML = `<div class="wrap empty">${artEl('owl-empty', 'owl')}<p>${esc(err.message || 'Something went wrong.')}</p></div>`;
      }
      hydrateArt(main);
      return;
    }
  }
  main.innerHTML = `<div class="wrap empty">${artEl('owl-empty', 'owl')}<p>This page is not in the index.</p></div>`;
  hydrateArt(main);
}

document.addEventListener('click', (e) => {
  const a = e.target.closest('a');
  if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  const href = a.getAttribute('href');
  if (!href || !href.startsWith('/') || href.startsWith('//') || a.target === '_blank' || href.startsWith('/api/')) return;
  e.preventDefault();
  if (href !== location.pathname + location.search) navigate(href);
  window.scrollTo({ top: 0 });
});
window.addEventListener('popstate', render);

// theme
$('.theme-toggle').addEventListener('click', () => {
  const root = document.documentElement;
  const dark = root.dataset.theme ? root.dataset.theme === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
  root.dataset.theme = dark ? 'light' : 'dark';
  try { localStorage.setItem('spindle-theme', root.dataset.theme); } catch (e) { /* private mode */ }
  window.dispatchEvent(new Event('themechange'));
});

// ---------------------------------------------------------- the query box

const isPassage = (t) => {
  const words = t.trim().split(/\s+/).filter(Boolean).length;
  const sents = (t.match(/[.!?](\s|$)/g) || []).length;
  return words >= 28 || (sents >= 3 && words >= 18) || /\n\s*\n/.test(t.trim());
};

function queryBox({ value = '', placeholder, compact = false, autofocus = false, forceMode = null } = {}) {
  const el = document.createElement('form');
  el.className = 'query';
  el.setAttribute('role', 'search');
  el.innerHTML = `
    <label class="sr-only" for="q">Describe a motif, or paste a tale</label>
    <textarea id="q" rows="1" spellcheck="true" placeholder="${esc(placeholder || 'Describe a motif — or paste a whole tale…')}">${esc(value)}</textarea>
    <div class="query-bar">
      <span class="mode" aria-live="polite"></span>
      <span class="kbd"></span>
      <button class="btn" type="submit">Search</button>
    </div>`;
  const ta = $('textarea', el);
  const modeEl = $('.mode', el);
  const btn = $('button[type=submit]', el);
  const kbd = $('.kbd', el);
  let override = forceMode;

  const mode = () => override || (isPassage(ta.value) ? 'passage' : 'describe');
  const grow = () => {
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, window.innerHeight * 0.5) + 'px';
  };
  const update = () => {
    const m = mode();
    const empty = !ta.value.trim();
    btn.textContent = m === 'passage' ? 'Find motifs' : 'Search';
    kbd.textContent = m === 'passage' ? '⌘↵' : '↵';
    if (empty) { modeEl.innerHTML = '<span>A few words, a motif number like <b>D1960.3</b>, or a whole tale.</span>'; return; }
    modeEl.innerHTML = m === 'passage'
      ? `<b>Reading a passage</b> <button type="button" data-m="describe">search it as a description instead</button>`
      : `<b>Describing a motif</b> ${ta.value.trim().split(/\s+/).length > 6 ? '<button type="button" data-m="passage">read it as a passage instead</button>' : ''}`;
  };
  modeEl.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-m]');
    if (b) { override = b.dataset.m; update(); ta.focus(); }
  });
  ta.addEventListener('input', () => { if (!forceMode) override = null; grow(); update(); });
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey || (mode() === 'describe' && !e.shiftKey))) {
      e.preventDefault();
      el.requestSubmit();
    }
  });
  el.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = ta.value.trim();
    if (!text) { ta.focus(); return; }
    if (mode() === 'passage') {
      try { sessionStorage.setItem('spindle-passage', text); } catch (err) { /* ignore */ }
      navigate('/read?go=1');
    } else {
      const u = new URL('/search', location.origin);
      const keep = new URLSearchParams(location.pathname === '/search' ? location.search : '');
      for (const k of ['in', 'region', 'culture']) keep.getAll(k).forEach((v) => u.searchParams.append(k, v));
      u.searchParams.set('q', text);
      navigate(u.pathname + u.search);
    }
  });
  requestAnimationFrame(() => { grow(); update(); if (autofocus) { ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); } });
  if (compact) el.classList.add('compact');
  return el;
}

// ------------------------------------------------------------------ home

const EXAMPLES = [
  'a man who turns into a wolf',
  'the youngest daughter is kind to an old woman',
  'animals that help the hero because he spared them',
  'why the sea is salt',
  'a ghost returns to reveal buried treasure',
  'trickster pretends to be dead',
  'D1960.3',
];

async function viewHome() {
  document.title = "Spindle · Thompson's Motif-Index";
  main.innerHTML = `
    <div class="wrap fade-in">
      <section class="hero">
        <span class="hero-art" data-art="hero"></span>
        <h1>Thompson’s Motif-Index, <i>spun anew</i></h1>
        <p class="lede">Forty-six thousand motifs of folk literature, findable by what they mean. Describe one in your own words, or paste a tale and see which motifs it holds.</p>
        <div class="home-query"></div>
        <div class="examples">
          <span class="label eyebrow">or try</span>
          ${EXAMPLES.map((x) => `<a class="chip" href="/search?q=${encodeURIComponent(x)}">${esc(x)}</a>`).join('')}
          <a class="chip" href="/read?sample=0">✶ paste <i>Hansel and Gretel</i></a>
        </div>
      </section>

      <section class="home-section feature">
        <div>
          <div class="section-head"><h2>Three ways in</h2></div>
          <div class="ways">
            <div class="way"><span class="num">i</span><div><h3><a href="/search">Describe</a></h3><p>Say what happens — “a girl must not look back” — and Spindle finds the motifs that mean it, however Thompson worded them.</p></div></div>
            <div class="way"><span class="num">ii</span><div><h3><a href="/read">Read a tale</a></h3><p>Paste a story. Each sentence is matched against the index, and the motifs are marked in the margin of your text.</p></div></div>
            <div class="way"><span class="num">iii</span><div><h3><a href="/browse">Browse</a> or <a href="/map">wander</a></h3><p>Walk Thompson’s own tree from A to Z, or drift across a map where kindred motifs lie together, whatever their letter.</p></div></div>
          </div>
        </div>
        <div class="leaf oracle" aria-live="polite">
          ${['tl', 'tr', 'bl', 'br'].map((c) => `<span class="corner ${c}" data-art="corner"></span>`).join('')}
          <div class="oracle-body"><div class="loading">${whorl()} drawing a motif…</div></div>
        </div>
      </section>

      <section class="home-section">
        <div class="section-head"><h2>The twenty-three branches</h2><span class="aside">Thompson’s classification, A to Z</span></div>
        <div class="cats"></div>
      </section>
    </div>`;
  $('.home-query', main).append(queryBox({ autofocus: matchMedia('(min-width: 760px)').matches }));
  hydrateArt(main);

  const m = await meta();
  const counts = await catCounts();
  $('.cats', main).innerHTML = LETTERS.map((L) => `
    <a class="cat" href="/browse/${L}">
      <span class="cat-art" data-art="${L}"></span>
      <span><span class="cat-letter">${L}</span> <span class="cat-name">${esc(m.categories[L])}</span></span>
      <span class="cat-count">${fmt(counts[L] || 0)} motifs</span>
    </a>`).join('');
  hydrateArt(main);
  oracle();
}

let TREE = null;
const tree = async () => (TREE ??= await getJSON('/api/tree'));
async function catCounts() {
  const t = await tree();
  return Object.fromEntries(t.map((c) => [c.id, c.count]));
}

async function oracle() {
  const box = $('.oracle-body', main);
  if (!box) return;
  const m = await getJSON('/api/random?seed=' + Math.floor(Math.random() * 1e9));
  box.innerHTML = `
    <div class="eyebrow"><span>A motif, at random</span><button class="again" type="button">another ↻</button></div>
    <h3><a href="/motif/${encodeURIComponent(m.id)}">${esc(trimDot(m.title))}</a></h3>
    ${m.note ? `<p>${esc(m.note)}</p>` : ''}
    <div><span class="mid">${esc(m.id)}</span> <span class="muted">· ${esc(m.path.map((p) => trimDot(p.title)).slice(-2).join(' › '))}</span></div>
    ${m.cultures.length ? `<div class="muted" style="font-size:15px;margin-top:6px;font-style:italic">${esc(m.cultures.slice(0, 6).join(', '))}${m.n_cultures > 6 ? ' …' : ''}</div>` : ''}`;
  $('.again', box).addEventListener('click', oracle);
}

// --------------------------------------------------------------- search

async function viewSearch() {
  const params = new URLSearchParams(location.search);
  const q = params.get('q') || '';
  const within = params.getAll('in');
  const regions = params.getAll('region');
  const cultures = params.getAll('culture');
  const types = params.getAll('type');
  document.title = q ? `${q} · Spindle` : 'Search · Spindle';

  main.innerHTML = `
    <div class="wrap">
      <div class="search-top"></div>
      <div class="layout">
        <aside class="facets" aria-label="Refine"></aside>
        <section class="results-col" aria-live="polite"><div class="loading">${whorl()} searching the index…</div></section>
        <aside class="detail-pane" aria-label="Motif"></aside>
      </div>
    </div>`;
  $('.search-top', main).append(queryBox({ value: q, autofocus: !q, forceMode: 'describe', placeholder: 'Describe a motif in your own words…' }));
  hydrateArt(main);

  if (!q && !within.length && !regions.length && !cultures.length && !types.length) {
    $('.results-col', main).innerHTML = `<div class="empty">${artEl('owl-empty', 'owl')}<p>Describe what happens, who acts, what is forbidden or transformed. Plain words are fine — Spindle searches by meaning.</p></div>`;
    $('.layout', main).classList.add('no-detail');
    renderFacets({}, { within, regions, cultures });
    return;
  }

  const u = new URLSearchParams({ q, k: '60' });
  within.forEach((v) => u.append('in', v));
  regions.forEach((v) => u.append('region', v));
  cultures.forEach((v) => u.append('culture', v));
  types.forEach((v) => u.append('type', v));
  const t0 = performance.now();
  const data = await getJSON('/api/search?' + u);
  const ms = Math.round(performance.now() - t0);
  const res = data.results;
  renderFacets(data.facets, { within, regions, cultures, types });

  const col = $('.results-col', main);
  const active = [...within.map((v) => ['in', v]), ...regions.map((v) => ['region', v]), ...cultures.map((v) => ['culture', v]), ...types.map((v) => ['type', v])];
  col.innerHTML = `
    <div class="results-meta">
      <span>${res.length ? `${res.length === 60 ? 'Best 60' : res.length} motif${res.length === 1 ? '' : 's'}` : 'Nothing found'}${q ? ` for <i>${esc(q)}</i>` : ''} <span class="muted">· ${ms} ms</span></span>
      ${active.length ? `<span class="active">${active.map(([k, v]) => `<a class="chip" aria-pressed="true" href="${esc(withoutParam(k, v))}">${esc(labelFor(k, v))} ✕</a>`).join('')}</span>` : ''}
    </div>
    ${q && res.length && res[0].score < 0.25 && res[0].via === 'meaning' && !active.length ? `<p class="weak">Nothing in the index matches this closely; these are distant guesses. Thompson may use other words — try describing what happens.</p>` : ''}
    ${res.length ? `<ol class="results">${res.map(resultItem).join('')}</ol>` : `<div class="empty">${artEl('owl-empty', 'owl')}<p>The owl found nothing. Try other words, or loosen the filters.</p></div>`}`;
  hydrateArt(col);

  const pane = $('.detail-pane', main);
  const wide = () => matchMedia('(min-width: 1181px)').matches;
  let current = null;
  const select = async (id, { scroll = false } = {}) => {
    if (!wide()) { navigate('/motif/' + encodeURIComponent(id)); return; }
    current = id;
    $$('.result', col).forEach((r) => r.setAttribute('aria-current', String(r.dataset.id === id)));
    const li = $(`.result[data-id="${CSS.escape(id)}"]`, col);
    if (scroll && li) li.scrollIntoView({ block: 'nearest' });
    pane.innerHTML = `<div class="loading">${whorl()}</div>`;
    hydrateArt(pane);
    const m = await getJSON('/api/motif/' + encodeURIComponent(id));
    if (current !== id) return;
    pane.innerHTML = `<div class="leaf motif fade-in">${motifHTML(m)}</div>`;
    pane.scrollTop = 0;
    wireMotif(pane, m);
    hydrateArt(pane);
  };
  col.addEventListener('click', (e) => {
    const r = e.target.closest('.result');
    if (!r || e.metaKey || e.ctrlKey) return;
    e.preventDefault();
    select(r.dataset.id);
  });
  const onKey = (e) => {
    if (e.target.matches('textarea, input')) return;
    if (!['ArrowDown', 'ArrowUp', 'j', 'k'].includes(e.key)) return;
    const ids = $$('.result', col).map((r) => r.dataset.id);
    if (!ids.length) return;
    e.preventDefault();
    const i = ids.indexOf(current);
    const next = e.key === 'ArrowDown' || e.key === 'j' ? Math.min(ids.length - 1, i + 1) : Math.max(0, i - 1);
    select(ids[next], { scroll: true });
  };
  document.addEventListener('keydown', onKey);
  if (res.length && wide()) select(res[0].id);
  else $('.layout', main).classList.toggle('no-detail', !wide());
  return () => document.removeEventListener('keydown', onKey);
}

function labelFor(k, v) {
  if (k === 'in') return LETTERS.includes(v) ? `${v} · ${META?.categories?.[v] || ''}` : v;
  if (k === 'type') return `Type ${v}`;
  return v;
}
function withoutParam(k, v) {
  const p = new URLSearchParams(location.search);
  const vals = p.getAll(k).filter((x) => x !== v);
  p.delete(k);
  vals.forEach((x) => p.append(k, x));
  return '/search?' + p;
}
function withParam(k, v) {
  const p = new URLSearchParams(location.search);
  if (!p.getAll(k).includes(v)) p.append(k, v);
  return '/search?' + p;
}

function resultItem(r) {
  const path = r.path.filter((p) => p.id.length > 1).slice(-2);
  return `
    <li><a class="result" data-id="${esc(r.id)}" href="/motif/${encodeURIComponent(r.id)}">
      <div class="result-head"><span class="mid">${esc(r.id)}</span><span class="result-title">${esc(r.title)}</span>
        <span class="score" title="match ${(r.score * 100).toFixed(0)}%"><i style="width:${Math.max(4, r.score * 100)}%"></i></span></div>
      ${r.note ? `<div class="result-note">${esc(r.note)}</div>` : ''}
      <div class="result-path">${path.map((p) => `<span>${esc(trimDot(p.title))}</span>`).join('')}</div>
      ${r.via === 'refs' ? `<div class="result-cult">named in the references</div>` : ''}
      ${r.cultures.length ? `<div class="result-cult">${esc(r.cultures.slice(0, 5).join(', '))}${r.n_cultures > 5 ? ` and ${r.n_cultures - 5} more` : ''}</div>` : ''}
    </a></li>`;
}

async function renderFacets(f, sel) {
  const m = await meta();
  const box = $('.facets', main);
  if (!box) return;
  const cats = Object.entries(f.categories || {}).sort((a, b) => b[1] - a[1]);
  const regs = Object.entries(f.regions || {}).sort((a, b) => b[1] - a[1]);
  box.innerHTML = `
    <div class="facet-group">
      <h4>Branch</h4>
      ${sel.within.filter((w) => !cats.find(([L]) => L === w)).map((w) => facetBtn('in', w, labelFor('in', w), null, true)).join('')}
      ${cats.map(([L, n]) => facetBtn('in', L, m.categories[L], n, sel.within.includes(L), L)).join('') || '<span class="muted" style="font-size:15px">—</span>'}
    </div>
    <div class="facet-group">
      <h4>Attested in</h4>
      ${(regs.length ? regs : m.regions.map(([r]) => [r, null]).slice(0, 14)).map(([r, n]) => facetBtn('region', r, r, n, sel.regions.includes(r))).join('')}
    </div>
    <div class="facet-group">
      <h4>Culture</h4>
      <input class="facet-filter" list="cultures" placeholder="e.g. Irish, Japanese…" aria-label="Filter by culture">
      <datalist id="cultures">${m.cultures.map(([c]) => `<option value="${esc(c)}">`).join('')}</datalist>
      ${sel.cultures.map((c) => facetBtn('culture', c, c, null, true)).join('')}
    </div>`;
  hydrateArt(box);
  $('.facet-filter', box).addEventListener('change', (e) => {
    const v = e.target.value.trim();
    if (v) navigate(withParam('culture', v));
  });
  box.addEventListener('click', (e) => {
    const b = e.target.closest('.facet');
    if (!b) return;
    navigate(b.getAttribute('aria-pressed') === 'true' ? withoutParam(b.dataset.k, b.dataset.v) : withParam(b.dataset.k, b.dataset.v));
  });
}
function facetBtn(k, v, label, n, on, artName) {
  return `<button class="facet" type="button" data-k="${k}" data-v="${esc(v)}" aria-pressed="${on}">
    ${artName ? `<span class="fart" data-art="${artName}"></span>` : ''}<span>${esc(label)}</span>${n != null ? `<span class="n">${n}</span>` : ''}</button>`;
}

// ---------------------------------------------------------------- motif

function crumbsHTML(path) {
  return path.map((p) => {
    const href = p.kind === 'motif' ? `/motif/${encodeURIComponent(p.id)}` : `/browse/${encodeURIComponent(p.id)}`;
    const label = p.kind === 'category' ? `${p.id}. ${p.title}` : trimDot(p.title);
    return `<a href="${href}">${esc(label)}</a>`;
  }).join('<span class="sep">›</span>');
}

const ID_IN_TEXT = /(?<![A-Za-z\d])([A-HJ-NP-Z]\d{1,4}(?:\.\d+)*)(?=[\s.,;:)\]]|$)/g;
function refsHTML(refs) {
  let s = esc(refs);
  s = s.replace(/(^|[;—]\s*|\.\s+|\(\s*)(\*{0,2}[A-Z][A-Za-zÀ-ÿ.’'\- ]{1,40}?(?:\s\([^)]{1,50}\))?)(:)/g, '$1<span class="lab">$2</span>$3');
  s = s.replace(ID_IN_TEXT, (m, id) => `<a class="xr" href="/motif/${encodeURIComponent(id)}">${id}</a>`);
  return s;
}

function mlist(items, { sim = false, ctx = true } = {}) {
  return `<ul class="mlist">${items.map((x) => {
    const where = ctx && x.path ? x.path.filter((p) => p.id.length > 1).slice(-1).map((p) => trimDot(p.title))[0] : '';
    return `<li><a class="mid" href="/motif/${encodeURIComponent(x.id)}">${esc(x.id)}</a>
      <span><a href="/motif/${encodeURIComponent(x.id)}">${esc(x.title)}</a>${x.n_children ? `<span class="more">+${x.n_children}</span>` : ''}${sim ? `<span class="sim" style="opacity:${Math.max(0.15, (x.sim - 0.6) * 2.5)}"></span>` : ''}
      ${where ? `<span class="ctx">${esc(where)}</span>` : ''}</span></li>`;
  }).join('')}</ul>`;
}

function motifHTML(m, { full = false } = {}) {
  const regions = {};
  // group cultures by region using the facet table in META
  for (const c of m.cultures || []) {
    const r = regionOf(c, m.regions);
    (regions[r] ??= []).push(c);
  }
  const children = (m.children || []).filter((c) => c.kind === 'motif');
  const refs = m.refs || '';
  const longRefs = refs.length > 700;
  return `
    ${!full ? `<a class="open-full" href="/motif/${encodeURIComponent(m.id)}">open page ↗</a>` : ''}
    <div class="crumbs">${crumbsHTML(m.path)}</div>
    <div class="motif-head">
      <span class="emblem" data-art="${m.letter}"></span>
      <div>
        <div class="motif-id"><span class="mid">${esc(m.id)}</span><button class="copy" type="button" title="Copy motif number and headline">copy</button></div>
        <h2>${esc(m.title)}</h2>
      </div>
    </div>
    ${m.note ? `<p class="note">${esc(m.note)}</p>` : ''}
    ${(m.alt_titles || []).length ? `<div class="alt">Also printed as: ${m.alt_titles.map(esc).join('; ')}</div>` : ''}

    ${Object.keys(regions).length ? `<section><h4>Attested in <span class="hint">${m.cultures.length} tradition${m.cultures.length === 1 ? '' : 's'}</span></h4>
      <div class="regions">${Object.entries(regions).map(([r, cs]) => `<div class="region"><span class="rname">${esc(r)}</span><span class="cul">${cs.map((c) => `<a class="chip" href="/search?culture=${encodeURIComponent(c)}">${esc(c)}</a>`).join('')}</span></div>`).join('')}</div></section>` : ''}

    ${(m.types || []).length ? `<section><h4>Tale types <span class="hint">Aarne–Thompson</span></h4><div class="types">${m.types.map((t) => `<a class="chip" href="/search?type=${encodeURIComponent(t)}">Type ${esc(t)}</a>`).join('')}</div></section>` : ''}

    ${refs ? `<section><h4>References</h4><div class="refs">${longRefs ? `<span class="short">${refsHTML(refs.slice(0, 520).replace(/\s\S*$/, ''))} …</span><details><summary>all references</summary>${refsHTML(refs)}</details>` : refsHTML(refs)}</div></section>` : ''}

    ${children.length ? `<section><h4>Subdivisions <span class="hint">${children.length}</span></h4>${mlist(children.slice(0, full ? 400 : 40), { ctx: false })}${!full && children.length > 40 ? `<a class="muted" href="/motif/${encodeURIComponent(m.id)}">all ${children.length} →</a>` : ''}</section>` : ''}

    ${(m.cf || []).length ? `<section><h4>Compare <span class="hint">Thompson’s cross-references</span></h4>${mlist(m.cf)}</section>` : ''}
    ${(m.cited_by || []).length ? `<section><h4>Referred to from</h4>${mlist(m.cited_by)}</section>` : ''}

    ${(m.echoes || []).length ? `<section><h4>Echoes elsewhere <span class="hint">similar motifs filed under other headings</span></h4>${mlist(m.echoes, { sim: true })}</section>` : ''}
    ${(m.kin || []).length ? `<section><h4>Close kin <span class="hint">nearby in meaning and place</span></h4>${mlist(m.kin, { sim: true })}</section>` : ''}

    ${m.prev || m.next ? `<nav class="sibnav">
      ${m.prev ? `<a class="prev" href="/motif/${encodeURIComponent(m.prev.id)}"><span class="dir">‹ previous</span><span class="mid">${esc(m.prev.id)}</span> ${esc(m.prev.title)}</a>` : '<span></span>'}
      ${m.next ? `<a class="next" href="/motif/${encodeURIComponent(m.next.id)}"><span class="dir">next ›</span><span class="mid">${esc(m.next.id)}</span> ${esc(m.next.title)}</a>` : ''}
    </nav>` : ''}`;
}

let REGION_OF = null;
function regionOf(culture, regions) {
  // the server sends a motif's cultures and regions separately; recover the pairing heuristically
  if (!REGION_OF) REGION_OF = {};
  if (REGION_OF[culture]) return REGION_OF[culture];
  return regions.length === 1 ? regions[0] : guessRegion(culture, regions);
}
function guessRegion(c, regions) {
  const rules = [
    ['Celtic', /irish|welsh|scot|breton|celtic|manx|cornish/i], ['Northern Europe', /icel|norse|danish|norw|swed|finn|lapp|eston|livon|lithuan|latvia/i],
    ['Arctic', /eskimo|greenland/i], ['South Asia', /india|hindu|buddh|ceylon|tibet|panchatantra/i], ['East Asia', /chin|japan|korea|annam|burm|siam|indo-chin/i],
    ['Africa', /africa|ekoi|fang|zulu|hottentot|bushman|kaffir|congo|gold coast|hausa|yoruba|basuto|benga|ila|cape verde/i],
    ['North America', /north american indian|tahltan|kaska|ojibwa|zu/i], ['Latin America', /south american|aztec|maya|inca|argentin|chile|brazil/i],
    ['Oceania', /hawai|tahiti|tonga|maori|marques|tuamotu|samoa|polynes|melanes|papua|fiji|indones|philipp|borneo|easter|cook|austral|mono/i],
    ['Mediterranean & Near East', /greek|roman|jewish|hebrew|arab|persia|babylon|egypt|turk|armenia|syria/i],
    ['Siberia & Central Asia', /siberia|buriat|koryak|yakut|chukch|tatar|kalm|kirg|mongol/i],
    ['Eastern Europe', /russia|slav|czech|polish|serb|ruman|romania|hungar|cherem|mordvin|votyak/i],
    ['Afro-Caribbean & North American folk', /united states|missouri|african american|jamaica|west indies|bahama|haiti|louisiana|carolina|new york|canad|virginia|kentucky|ozark/i],
    ['Western Europe', /./],
  ];
  for (const [r, re] of rules) if (re.test(c) && (regions.includes(r) || r === 'Western Europe')) return regions.includes(r) ? r : regions[0] || r;
  return regions[0] || 'Elsewhere';
}

function wireMotif(root, m) {
  const copy = $('.copy', root);
  if (copy) copy.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(`${m.id}. ${m.title}`); toast('Copied ' + m.id); } catch (e) { toast('Could not copy'); }
  });
}

async function viewMotif(id) {
  main.innerHTML = `<div class="wrap motif-page"><div class="loading">${whorl()} opening ${esc(id)}…</div></div>`;
  hydrateArt(main);
  const m = await getJSON('/api/motif/' + encodeURIComponent(id));
  if (m.kind !== 'motif') { navigate('/browse/' + encodeURIComponent(m.id), { replace: true }); return; }
  document.title = `${m.id} ${trimDot(m.title)} · Spindle`;
  main.innerHTML = `<div class="wrap motif-page fade-in"><article class="leaf motif full">
    ${['tl', 'tr', 'bl', 'br'].map((c) => `<span class="corner ${c}" data-art="corner"></span>`).join('')}
    ${motifHTML(m, { full: true })}</article></div>`;
  wireMotif(main, m);
  const onKey = (e) => {
    if (e.target.matches('textarea, input')) return;
    if (e.key === 'ArrowLeft' && m.prev) navigate('/motif/' + encodeURIComponent(m.prev.id));
    if (e.key === 'ArrowRight' && m.next) navigate('/motif/' + encodeURIComponent(m.next.id));
  };
  document.addEventListener('keydown', onKey);
  return () => document.removeEventListener('keydown', onKey);
}

// --------------------------------------------------------------- browse

async function viewBrowse(id) {
  const m = await meta();
  document.title = 'Browse · Spindle';
  const letter = id ? id[0] : null;
  main.innerHTML = `<div class="wrap browse-page fade-in">
      <h1>Browse the index</h1>
      <nav class="browse-letters" aria-label="Branches">${LETTERS.map((L) => `<a href="/browse/${L}" title="${esc(m.categories[L])}" ${L === letter ? 'aria-current="page"' : ''}>${L}</a>`).join('')}</nav>
      <div class="browse-body"></div></div>`;
  const body = $('.browse-body', main);
  if (!id) {
    const counts = await catCounts();
    body.innerHTML = `<p class="muted" style="font-style:italic;max-width:60ch">Thompson arranged the motifs in a tree: twenty-three lettered branches, divided into numbered sections and subdivided again and again, from the general (<span class="mid">D100</span> transformation: man to animal) to the particular (<span class="mid">D113.1.1</span> werwolf).</p>
      <div class="cats" style="margin-top:20px">${LETTERS.map((L) => `
        <a class="cat" href="/browse/${L}"><span class="cat-art" data-art="${L}"></span>
        <span><span class="cat-letter">${L}</span> <span class="cat-name">${esc(m.categories[L])}</span></span>
        <span class="cat-count">${fmt(counts[L] || 0)} motifs</span></a>`).join('')}</div>`;
    return;
  }
  const node = await getJSON('/api/motif/' + encodeURIComponent(id));
  if (node.kind === 'motif' && !node.children.length) { navigate('/motif/' + encodeURIComponent(id), { replace: true }); return; }
  document.title = `${node.kind === 'category' ? node.id + '. ' : ''}${trimDot(node.title)} · Browse · Spindle`;
  const counts = await catCounts();
  body.innerHTML = `
    ${node.path.length ? `<div class="motif"><div class="crumbs">${crumbsHTML(node.path)}</div></div>` : ''}
    <div class="browse-cat-head">
      <span class="emblem" data-art="${node.id[0]}"></span>
      <div>
        <div class="letter">${node.kind === 'category' ? node.id : `<span class="mid">${esc(node.id)}</span>`}</div>
        <h2 style="font-size:clamp(28px,4vw,40px)">${esc(trimDot(node.title))}</h2>
        <div class="muted">${node.kind === 'category' ? `${fmt(counts[node.id])} motifs` : `${node.children.length} subdivision${node.children.length === 1 ? '' : 's'}`}
        ${node.kind === 'motif' ? ` · <a href="/motif/${encodeURIComponent(node.id)}">the motif itself →</a>` : ''}
        · <a href="/search?in=${encodeURIComponent(node.id)}">search within</a></div>
      </div>
    </div>
    <ul class="outline">${node.children.map(outlineNode).join('')}</ul>`;
  // open the first level so the page shows the shape of the branch at a glance
  if (node.kind !== 'motif' && node.children.length <= 16) {
    await Promise.all(node.children.filter((c) => c.n_children && c.n_children <= 40).map(async (c) => {
      const li = $(`li[data-id="${CSS.escape(c.id)}"]`, body);
      const sub = await getJSON('/api/motif/' + encodeURIComponent(c.id));
      const ul = document.createElement('ul');
      ul.innerHTML = sub.children.map(outlineNode).join('');
      li.append(ul);
      $('.tw', li).setAttribute('aria-expanded', 'true');
    }));
  }
  body.addEventListener('click', async (e) => {
    const tw = e.target.closest('.tw');
    if (!tw || tw.classList.contains('leafy')) return;
    const li = tw.closest('li');
    const open = tw.getAttribute('aria-expanded') === 'true';
    tw.setAttribute('aria-expanded', String(!open));
    let ul = $(':scope > ul', li);
    if (open) { ul?.remove(); return; }
    ul = document.createElement('ul');
    ul.innerHTML = `<li class="muted" style="font-size:15px;padding:2px 30px">…</li>`;
    li.append(ul);
    const sub = await getJSON('/api/motif/' + encodeURIComponent(li.dataset.id));
    ul.innerHTML = sub.children.map(outlineNode).join('');
  });
}

function outlineNode(c) {
  const isSection = c.kind === 'section';
  const href = isSection ? `/browse/${encodeURIComponent(c.id)}` : `/motif/${encodeURIComponent(c.id)}`;
  return `<li data-id="${esc(c.id)}"><div class="node ${c.kind}">
    <button class="tw ${c.n_children ? '' : 'leafy'}" type="button" aria-expanded="false" aria-label="Expand ${esc(c.id)}">▸</button>
    <a class="mid" href="${href}">${esc(c.id)}</a>
    <a class="t" href="${href}">${esc(trimDot(c.title))}</a>${c.n_children ? `<span class="cnt">${c.n_children}</span>` : ''}${c.has_note ? '<span class="dot" title="has an explanatory note">✶</span>' : ''}
  </div></li>`;
}

// ----------------------------------------------------------------- read

async function viewRead() {
  document.title = 'Read a tale · Spindle';
  const params = new URLSearchParams(location.search);
  let text = '';
  try { text = sessionStorage.getItem('spindle-passage') || ''; } catch (e) { /* ignore */ }
  if (params.has('sample')) text = SAMPLES[+params.get('sample')]?.text || text;
  const m = await meta();

  main.innerHTML = `<div class="wrap read-page fade-in">
    <div class="read-intro">
      <h1>Read a tale</h1>
      <p>Paste a folktale, legend or myth. Spindle reads it sentence by sentence and marks the motifs it recognises.</p>
    </div>
    <div class="read-input"></div>
    <div class="examples" style="justify-content:flex-start;margin-top:12px">
      <span class="eyebrow" style="margin-right:4px">samples</span>
      ${SAMPLES.map((s, i) => `<button class="chip" type="button" data-sample="${i}">${esc(s.title)}</button>`).join('')}
    </div>
    <div class="read-out"></div>
  </div>`;
  const input = $('.read-input', main);
  const box = queryBox({ value: text, forceMode: 'passage', placeholder: 'Once upon a time…' });
  $('textarea', box).style.minHeight = '160px';
  input.append(box);
  $$('[data-sample]', main).forEach((b) => b.addEventListener('click', () => {
    const s = SAMPLES[+b.dataset.sample];
    try { sessionStorage.setItem('spindle-passage', s.text); } catch (e) { /* ignore */ }
    navigate('/read?go=1', { replace: true });
  }));
  if (text && (params.has('go') || params.has('sample'))) runRead(text, m);
}

async function runRead(text, m) {
  const out = $('.read-out', main);
  $('.read-input', main).hidden = true;
  $$('[data-sample]', main).forEach((b) => b.closest('.examples').hidden = true);
  out.innerHTML = `<div class="loading">${whorl()} reading…</div>`;
  hydrateArt(out);
  const res = await (await postJSON('/api/analyze', { text, k: 24 })).json();
  drawReading(text, res, m);
}

function drawReading(text, res, m, { glosses = null, status = '' } = {}) {
  const out = $('.read-out', main);
  const motifs = res.motifs;
  const canRead = m.reader.available;
  out.innerHTML = `
    <div class="read-grid">
      <div>
        <div class="passage" tabindex="0" aria-label="Your passage, with motifs marked">${passageHTML(text, motifs)}</div>
        <div class="passage-tools">
          <button class="btn ghost" type="button" data-act="edit">Edit the text</button>
          ${canRead ? `<button class="btn" type="button" data-act="close">Close reading</button>
            <span class="reader-status">${status || `a language model (${esc(m.reader.model)}) restates the tale as motifs first — slower, sharper`}</span>` : ''}
        </div>
      </div>
      <div>
        ${glosses ? `<div class="glosses"><h4>The close reader’s glosses</h4><ol>${glosses.map((g) => `<li>${esc(g.motif)}</li>`).join('')}</ol></div>` : ''}
        <div class="found-head"><h2>${motifs.length ? 'Motifs found' : 'No motifs found'}</h2><span class="muted">best first · hover to see where</span></div>
        <ol class="found">${motifs.map((x, i) => foundItem(x, i, text)).join('')}</ol>
      </div>
    </div>`;
  hydrateArt(out);
  const passage = $('.passage', out);
  const segs = $$('.seg', passage);
  const hot = (i, on) => {
    segs.forEach((s) => s.classList.toggle('hot', on && (s.dataset.m || '').split(' ').includes(String(i))));
    $$('.found .fm', out).forEach((f) => f.classList.toggle('hot', on && f.dataset.i === String(i)));
  };
  $$('.found .fm', out).forEach((f) => {
    f.addEventListener('mouseenter', () => {
      hot(f.dataset.i, true);
      const s = $(`.seg.hot`, passage);
      if (s && matchMedia('(min-width: 981px)').matches) {
        const pr = passage.getBoundingClientRect(), sr = s.getBoundingClientRect();
        if (sr.top < pr.top || sr.bottom > pr.bottom) passage.scrollTo({ top: passage.scrollTop + sr.top - pr.top - 60, behavior: 'smooth' });
      }
    });
    f.addEventListener('mouseleave', () => hot(f.dataset.i, false));
    f.addEventListener('click', (e) => { if (!e.target.closest('a')) navigate('/motif/' + encodeURIComponent(f.dataset.id)); });
  });
  segs.forEach((s) => {
    if (!s.dataset.m) return;
    s.addEventListener('mouseenter', () => {
      const ids = s.dataset.m.split(' ');
      $$('.found .fm', out).forEach((f) => f.classList.toggle('hot', ids.includes(f.dataset.i)));
      s.classList.add('hot');
    });
    s.addEventListener('mouseleave', () => { s.classList.remove('hot'); $$('.found .fm', out).forEach((f) => f.classList.remove('hot')); });
    s.addEventListener('click', () => {
      const first = $(`.found .fm[data-i="${s.dataset.m.split(' ')[0]}"]`, out);
      first?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    });
  });
  $('[data-act=edit]', out).addEventListener('click', () => {
    $('.read-input', main).hidden = false;
    $$('.examples', main).forEach((e) => e.hidden = false);
    out.innerHTML = '';
    $('.read-input textarea', main).focus();
  });
  const close = $('[data-act=close]', out);
  if (close) close.addEventListener('click', () => closeReading(text, res, m));
}

function passageHTML(text, motifs) {
  // split the text at every span boundary; each segment knows which motifs cover it
  const cuts = new Set([0, text.length]);
  motifs.forEach((x) => { cuts.add(x.span[0]); cuts.add(x.span[1]); });
  const pts = [...cuts].sort((a, b) => a - b);
  let html = '';
  for (let i = 0; i < pts.length - 1; i++) {
    const [a, b] = [pts[i], pts[i + 1]];
    const cover = motifs.map((x, j) => (x.span[0] <= a && x.span[1] >= b ? j : -1)).filter((j) => j >= 0);
    const piece = esc(text.slice(a, b));
    if (!cover.length) { html += piece; continue; }
    const lvl = cover.length >= 3 ? 3 : cover.length;
    html += `<span class="seg m${lvl}" data-m="${cover.join(' ')}">${piece}</span>`;
  }
  return html;
}

function foundItem(x, i, text) {
  const quote = text.slice(x.span[0], x.span[1]).trim();
  const short = quote.length > 140 ? quote.slice(0, 137).replace(/\s\S*$/, '') + ' …' : quote;
  return `<li><div class="fm" data-i="${i}" data-id="${esc(x.id)}">
    <a class="mid" href="/motif/${encodeURIComponent(x.id)}">${esc(x.id)}</a>
    <span class="t"><a href="/motif/${encodeURIComponent(x.id)}">${esc(x.title)}</a></span>
    <span class="conf" title="confidence ${(x.score * 100).toFixed(0)}%"><i style="width:${Math.max(6, x.score * 100)}%"></i></span>
    ${x.reading ? `<span class="reading">read as: ${esc(x.reading)}</span>` : ''}
    <span class="q">“${esc(short)}”</span>
  </div></li>`;
}

async function closeReading(text, res, m) {
  const out = $('.read-out', main);
  const btn = $('[data-act=close]', out);
  const status = $('.reader-status', out);
  btn.disabled = true;
  status.innerHTML = `${whorl()} the close reader is reading…`;
  hydrateArt(status);
  const started = performance.now();
  const tick = setInterval(() => {
    const s = Math.round((performance.now() - started) / 1000);
    const w = $('.reader-status', out);
    if (w && !w.dataset.done) w.lastChild.textContent = ` the close reader is reading… ${s}s`;
  }, 1000);
  try {
    const r = await postJSON('/api/read', { text, k: 24 });
    const reader = r.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    let glosses = null;
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl); buf = buf.slice(nl + 1);
        if (!line.trim()) continue;
        const ev = JSON.parse(line);
        if (ev.event === 'statements') {
          glosses = ev.statements;
          const st = $('.reader-status', out);
          if (st) st.lastChild.textContent = ` ${glosses.length} glosses; matching them to the index…`;
        } else if (ev.event === 'motifs') {
          clearInterval(tick);
          drawReading(text, ev, m, { glosses, status: `close reading by ${esc(m.reader.model)} · ${Math.round((performance.now() - started) / 1000)}s` });
          const b = $('[data-act=close]', $('.read-out', main));
          if (b) { b.disabled = true; b.textContent = 'Closely read ✓'; }
        } else if (ev.event === 'error') {
          throw new Error(ev.message);
        }
      }
    }
  } catch (err) {
    toast('Close reading failed: ' + err.message);
    btn.disabled = false;
    status.textContent = 'close reading failed';
  } finally {
    clearInterval(tick);
  }
}

// ------------------------------------------------------------------ map

async function viewMap() {
  document.title = 'Map · Spindle';
  const m = await meta();
  main.innerHTML = `<div class="map-page">
    <canvas aria-label="Map of all motifs"></canvas>
    <div class="map-panel">
      <h1>A map of motifs</h1>
      <p>Each point is one of ${fmt(m.count)} motifs, placed so that motifs alike in meaning lie together, whatever branch Thompson filed them under. Colour is the branch.</p>
      <form class="map-search"><input type="search" placeholder="Light up a theme: dragons, riddles…" aria-label="Highlight motifs on the map"></form>
      <div class="map-legend">${LETTERS.map((L) => `<button type="button" data-l="${L}" title="${esc(m.categories[L])}"><i style="background:${CAT_COLORS[L]}"></i>${L} ${esc(SHORT[L])}</button>`).join('')}</div>
    </div>
    <div class="map-tip"></div>
    <div class="map-hint">scroll to zoom · drag to pan · click a point to open it</div>
    <div class="loading" style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%)">${whorl()} unrolling the map…</div>
  </div>`;
  hydrateArt(main);
  const page = $('.map-page', main);
  const canvas = $('canvas', page);
  const tip = $('.map-tip', page);
  const [buf, idsTitles] = await Promise.all([
    fetch('/api/map').then((r) => r.arrayBuffer()),
    getJSON('/api/ids'),
  ]);
  $('.loading', page).remove();
  const n = idsTitles.length;
  const dv = new DataView(buf);
  const X = new Float32Array(n), Y = new Float32Array(n), C = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    X[i] = dv.getUint16(i * 5, true) / 65535;
    Y[i] = dv.getUint16(i * 5 + 2, true) / 65535;
    C[i] = dv.getUint8(i * 5 + 4);
  }
  // spatial grid for hover
  const G = 128;
  const grid = Array.from({ length: G * G }, () => []);
  for (let i = 0; i < n; i++) grid[Math.min(G - 1, (Y[i] * G) | 0) * G + Math.min(G - 1, (X[i] * G) | 0)].push(i);

  const off = new Set();
  let hi = null; // highlighted rows
  let hover = -1;
  let view = { s: 1, tx: 0, ty: 0 };
  let W = 0, H = 0, dpr = 1;
  const pad = 40;
  const base = () => Math.min(W, H) - pad * 2;
  const toScreen = (x, y) => {
    const b = base();
    return [(W - b) / 2 + x * b * view.s + view.tx, (H - b) / 2 + y * b * view.s + view.ty];
  };
  const toWorld = (sx, sy) => {
    const b = base();
    return [(sx - view.tx - (W - b) / 2) / (b * view.s), (sy - view.ty - (H - b) / 2) / (b * view.s)];
  };
  const resize = () => {
    dpr = window.devicePixelRatio || 1;
    W = page.clientWidth; H = page.clientHeight;
    canvas.width = W * dpr; canvas.height = H * dpr;
    draw();
  };
  const ctx = canvas.getContext('2d');
  const colorsRGB = LETTERS.map((L) => CAT_COLORS[L]);
  let raf = 0;
  function draw() {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(() => {
      const css = getComputedStyle(document.documentElement);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = css.getPropertyValue('--paper');
      ctx.fillRect(0, 0, W, H);
      const r = Math.max(1.1, Math.min(4, 1.2 * Math.sqrt(view.s)));
      ctx.globalAlpha = hi ? 0.18 : 0.72;
      for (let c = 0; c < LETTERS.length; c++) {
        if (off.has(LETTERS[c])) continue;
        ctx.fillStyle = colorsRGB[c];
        ctx.beginPath();
        for (let i = 0; i < n; i++) {
          if (C[i] !== c) continue;
          const [sx, sy] = toScreen(X[i], Y[i]);
          if (sx < -5 || sy < -5 || sx > W + 5 || sy > H + 5) continue;
          ctx.rect(sx - r / 2, sy - r / 2, r, r);
        }
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      if (hi) {
        ctx.lineWidth = 1.5;
        hi.forEach((i, rank) => {
          const [sx, sy] = toScreen(X[i], Y[i]);
          ctx.strokeStyle = css.getPropertyValue('--ink');
          ctx.fillStyle = colorsRGB[C[i]];
          ctx.beginPath(); ctx.arc(sx, sy, rank < 10 ? 5 : 3.5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        });
        ctx.font = '14px "EB Garamond", serif';
        ctx.fillStyle = css.getPropertyValue('--ink');
        // label the best hits, skipping any label that would overlap one already placed
        const placed = [];
        let shown = 0;
        for (const i of hi) {
          if (shown >= 10) break;
          const [sx, sy] = toScreen(X[i], Y[i]);
          const label = idsTitles[i][1].length > 44 ? idsTitles[i][1].slice(0, 42) + '…' : idsTitles[i][1];
          const w = ctx.measureText(label).width;
          const box = [sx + 8, sy - 10, sx + 12 + w, sy + 6];
          if (box[2] > W || placed.some((b) => !(box[2] < b[0] || box[0] > b[2] || box[3] < b[1] || box[1] > b[3]))) continue;
          placed.push(box);
          ctx.fillStyle = css.getPropertyValue('--card');
          ctx.globalAlpha = 0.85;
          ctx.fillRect(box[0] - 2, box[1], box[2] - box[0], box[3] - box[1]);
          ctx.globalAlpha = 1;
          ctx.fillStyle = css.getPropertyValue('--ink');
          ctx.fillText(label, sx + 9, sy + 3);
          shown++;
        }
      }
      if (hover >= 0) {
        const [sx, sy] = toScreen(X[hover], Y[hover]);
        ctx.strokeStyle = css.getPropertyValue('--red');
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(sx, sy, 7, 0, Math.PI * 2); ctx.stroke();
      }
    });
  }
  function nearest(sx, sy) {
    const [wx, wy] = toWorld(sx, sy);
    const gx = (wx * G) | 0, gy = (wy * G) | 0;
    let best = -1, bd = Infinity;
    const rad = Math.max(1, Math.ceil(2 / view.s));
    for (let y = gy - rad; y <= gy + rad; y++) for (let x = gx - rad; x <= gx + rad; x++) {
      if (x < 0 || y < 0 || x >= G || y >= G) continue;
      for (const i of grid[y * G + x]) {
        if (off.has(LETTERS[C[i]])) continue;
        const [px, py] = toScreen(X[i], Y[i]);
        const d = (px - sx) ** 2 + (py - sy) ** 2;
        if (d < bd) { bd = d; best = i; }
      }
    }
    return bd < 144 ? best : -1;
  }
  let drag = null;
  canvas.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, y: e.clientY, tx: view.tx, ty: view.ty, moved: false }; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener('pointermove', (e) => {
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
    if (drag) {
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
      view.tx = drag.tx + dx; view.ty = drag.ty + dy;
      tip.style.display = 'none';
      draw();
      return;
    }
    const i = nearest(sx, sy);
    if (i !== hover) {
      hover = i;
      draw();
    }
    if (i >= 0) {
      tip.innerHTML = `<span class="mid">${esc(idsTitles[i][0])}</span>${esc(idsTitles[i][1])}`;
      tip.style.display = 'block';
      const tw = tip.offsetWidth;
      tip.style.left = Math.min(W - tw - 10, sx + 14) + 'px';
      tip.style.top = (sy + 14) + 'px';
    } else tip.style.display = 'none';
  });
  canvas.addEventListener('pointerup', (e) => {
    const wasDrag = drag?.moved;
    drag = null;
    if (!wasDrag && hover >= 0) navigate('/motif/' + encodeURIComponent(idsTitles[hover][0]));
  });
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
    const [wx, wy] = toWorld(sx, sy);
    view.s = Math.min(60, Math.max(0.7, view.s * Math.exp(-e.deltaY * 0.0015)));
    const [nx, ny] = toScreen(wx, wy);
    view.tx += sx - nx; view.ty += sy - ny;
    draw();
  }, { passive: false });
  $('.map-legend', page).addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const L = b.dataset.l;
    if (e.altKey || e.metaKey) { // solo
      const solo = off.size === LETTERS.length - 1 && !off.has(L);
      off.clear();
      if (!solo) LETTERS.forEach((x) => x !== L && off.add(x));
    } else off.has(L) ? off.delete(L) : off.add(L);
    $$('.map-legend button', page).forEach((x) => x.classList.toggle('off', off.has(x.dataset.l)));
    draw();
  });
  const rowOf = new Map(idsTitles.map(([id], i) => [id, i]));
  $('.map-search', page).addEventListener('submit', async (e) => {
    e.preventDefault();
    const q = $('input', e.target).value.trim();
    if (!q) { hi = null; draw(); return; }
    const d = await getJSON('/api/search?' + new URLSearchParams({ q, k: '150' }));
    hi = d.results.map((r) => rowOf.get(r.id)).filter((i) => i != null);
    if (hi.length) { // fly to the centre of the top results
      const top = hi.slice(0, 15);
      const cx = top.reduce((s, i) => s + X[i], 0) / top.length, cy = top.reduce((s, i) => s + Y[i], 0) / top.length;
      view.s = Math.max(view.s, 2.5);
      const [sx, sy] = toScreen(cx, cy);
      view.tx += W / 2 - sx; view.ty += H / 2 - sy;
    }
    draw();
  });
  $('.map-search input', page).addEventListener('input', (e) => { if (!e.target.value) { hi = null; draw(); } });
  const ro = new ResizeObserver(resize);
  ro.observe(page);
  window.addEventListener('themechange', draw);
  const mq = matchMedia('(prefers-color-scheme: dark)');
  mq.addEventListener('change', draw);
  resize();
  return () => { ro.disconnect(); window.removeEventListener('themechange', draw); mq.removeEventListener('change', draw); };
}

// ---------------------------------------------------------------- about

async function viewAbout() {
  document.title = 'About · Spindle';
  const m = await meta();
  main.innerHTML = `<article class="wrap about fade-in">
    <h1>About Spindle</h1>
    <p>Stith Thompson’s <i>Motif-Index of Folk-Literature</i> (1932–36; revised and enlarged 1955–58) classifies the recurring elements of traditional narrative — the swan maiden, the forbidden chamber, the trickster who feigns death — into a tree of some ${fmt(m.count)} numbered motifs, each with a trail of references to the collections where it occurs. It remains the common language of folk-narrative research, and it remains hard to search: a motif is found only if one guesses Thompson’s wording, or the branch he filed it under.</p>
    <p>Spindle searches it by meaning. It is a successor to MOMFER, the <i>Meertens Online Motif FindER</i> (Karsdorp, Van der Meulen, Meder &amp; Van den Bosch, <a href="https://doi.org/10.1080/0015587X.2015.1006954"><i>Folklore</i> 126 (2015)</a>), which expanded queries through WordNet. Where MOMFER matched words and their hypernyms, Spindle compares meanings directly.</p>

    <h2>How it works</h2>
    <ul>
      <li><b>Text.</b> The index was re-parsed from the HTML edition at ruthenia.ru, the fullest digital transcription of the revised edition, keeping each motif’s headline, explanatory note and references apart. A character-encoding fault that had turned <i>Métraux</i> into <i>Mйtraux</i> throughout was reversed.</li>
      <li><b>Tree.</b> Every motif is placed under its parent: the dotted subdivisions under their stems, the numbered motifs under Thompson’s own section headings (e.g. <span class="mid">D100–D199</span> <i>Transformation: man to animal</i>).</li>
      <li><b>Traditions.</b> The labels in the references (“Irish myth:”, “India:”, “N. A. Indian (Zuñi):”) are normalised into ${fmt(m.n_cultures)} traditions in ${m.regions.length} broad regions, so that results can be filtered by where a motif is attested.</li>
      <li><b>Meaning.</b> Each motif is embedded by two sentence encoders (<code>bge-base-en-v1.5</code> and <code>bge-m3</code>). A query is compared against all motifs at once; each encoder’s similarities are standardised and averaged, with a small nudge from exact word matches.</li>
      <li><b>Reading a tale.</b> Every sentence, every pair of sentences and every clause of a passage becomes a query. A motif’s score is its best match plus a share of its second best, so motifs attested twice rise; each is tied to the words that evidence it.</li>
      <li><b>Close reading.</b> ${m.reader.available ? `With a language model available (here <code>${esc(m.reader.model)}</code>), the tale is first restated as Thompson-style motif statements (“Crumb trail eaten by birds.”) whose register is much closer to the index’s, and these join the queries.` : 'When a language model is available (a local Ollama model, or Claude via the Anthropic API), the tale is first restated as Thompson-style motif statements, whose register is much closer to the index’s, and these join the queries.'}</li>
      <li><b>Echoes.</b> On every motif page, Spindle lists the most similar motifs that Thompson filed in other branches — the duplications and near-duplications he himself acknowledged (D1645.9 and F718.5, <i>well shines at night</i>), and many he did not.</li>
    </ul>

    <h2>How well it works</h2>
    <p>On a small hand-made benchmark of thirty paraphrased descriptions (“a slow animal wins a race against a fast one who takes a nap”), the intended motif is ranked first about half the time and is among the first ten four times in five. For fifteen retold tales with the motifs a folklorist would assign, about a third of those motifs appear among the first twenty found from the text alone, and about half with close reading. The rest are usually near misses: a sibling or parent of the intended motif. Treat the results as a well-read colleague’s suggestions, and check the index.</p>

    <h2>Searching</h2>
    <table>
      <tr><th>Type</th><th>Does</th></tr>
      <tr><td><code>a girl must not look back</code></td><td>search by meaning</td></tr>
      <tr><td><code>D1960.3</code></td><td>open a motif by number (and list its subdivisions)</td></tr>
      <tr><td><code>dragon in:B</code></td><td>search within a branch, section or motif</td></tr>
      <tr><td><code>trickster culture:Irish</code></td><td>only motifs attested in a tradition</td></tr>
      <tr><td><code>ogre region:"South Asia"</code></td><td>only motifs attested in a region</td></tr>
      <tr><td><code>type:300</code></td><td>motifs referring to a tale type</td></tr>
    </table>
    <p>In references, Thompson’s asterisk marks a reference with further bibliography, the double asterisk an especially full treatment.</p>
  </article>`;
}

hydrateArt(document);
render();
