"""Evaluate the engine end to end on the hand-made benchmark.

    uv run python pipeline/evaluate.py [-v] [--reader]

With --reader, close readings from the language model are used (cached in
data/build/readings.json; delete that file to re-read).
"""

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "pipeline"))
from eval_set import DESCRIPTIONS, PASSAGES  # noqa: E402
from spindle.engine import Engine  # noqa: E402

CACHE = ROOT / "data" / "build" / "readings.json"


def readings():
    from spindle.reader import Reader

    cache = json.load(open(CACHE)) if CACHE.exists() else {}
    missing = [t for t, _ in PASSAGES if t not in cache]
    if missing:
        r = Reader()
        for t in missing:
            cache[t] = r.read(t)
        json.dump(cache, open(CACHE, "w"), indent=1)
    return cache


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-v", action="store_true")
    ap.add_argument("--reader", action="store_true")
    args = ap.parse_args()
    e = Engine()
    e.warmup()

    h1 = h10 = mrr = 0
    t0 = time.time()
    for q, gold in DESCRIPTIONS:
        res = [mid for mid, *_ in e.search(q, k=10)]
        r = [i for i, mid in enumerate(res) if mid in gold]
        if r:
            h10 += 1
            h1 += r[0] == 0
            mrr += 1 / (r[0] + 1)
        elif args.v:
            print(f"   MISS {q[:60]!r} -> {res[:3]}")
    n = len(DESCRIPTIONS)
    print(f"descriptions: hit@1 {h1/n:.2f} hit@10 {h10/n:.2f} mrr@10 {mrr/n:.3f}  [{(time.time()-t0)/n*1000:.0f} ms/query]")

    modes = [("passages", None)] + ([("passages + reader", readings())] if args.reader else [])
    for name, R in modes:
        f10 = f20 = tot = 0
        t0 = time.time()
        for text, gold in PASSAGES:
            gold = [g for g in gold if g in e.nodes]
            res = e.analyze(text, k=20, statements=R[text] if R else None)["motifs"]
            got = [m["id"] for m in res]
            f20 += sum(1 for g in gold if g in got)
            f10 += sum(1 for g in gold if g in got[:10])
            tot += len(gold)
            if args.v:
                print(f"   {sum(1 for g in gold if g in got)}/{len(gold)} {text[:36]!r} top {got[:4]} "
                      f"missing {[g for g in gold if g not in got]}")
        print(f"{name}: recall@10 {f10/tot:.2f} recall@20 {f20/tot:.2f}  [{(time.time()-t0)/len(PASSAGES):.2f} s/passage]")


if __name__ == "__main__":
    main()
