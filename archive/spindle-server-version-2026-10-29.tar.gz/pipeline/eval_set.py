"""A small hand-made benchmark for motif retrieval.

DESCRIPTIONS: paraphrases a user might type, deliberately avoiding Thompson's
own wording. Any of the listed motifs counts as a hit.

PASSAGES: short retellings of well-known tales. Every listed motif is a motif
a folklorist would assign; we measure how many are found in the top 20.
"""

DESCRIPTIONS = [
    ("a man who turns into a wolf at night", ["D113.1.1", "D622.1", "D113.1"]),
    ("the prince searches the kingdom for the girl whose foot fits the lost shoe", ["H36.1"]),
    ("a witch lives in a house made of bread and sweets to lure children", ["G412.1", "F771.1.10"]),
    ("the youngest of three brothers succeeds after the elder ones fail", ["L10", "L13"]),
    ("whoever can make the sad princess laugh may marry her", ["H341"]),
    ("a monster asks a riddle and kills those who cannot answer", ["H541.1.1", "H541.1", "H761"]),
    ("musical instrument that forces everyone who hears it to dance", ["D1415.2.3", "D1415.2.1", "D1415.2", "D1415.2.2"]),
    ("the clever peasant lets the devil choose the tops of the crop, then plants turnips", ["K171.1"]),
    ("someone who can understand what the birds are saying", ["B216", "B215", "B165"]),
    ("the new bride is forbidden to open one room in the castle", ["C611", "C611.1"]),
    ("why the bear has only a stump for a tail", ["A2216.1"]),
    ("a bird woman whose feather cloak is stolen while she bathes so she must marry the thief", ["D361.1", "K1335"]),
    ("the giant cannot be killed because his life is hidden in an egg far away", ["E711.1", "E710"]),
    ("a piper whose music makes people follow him wherever he goes", ["D1427.1"]),
    ("the fox praises the crow's singing so it drops its food", ["K334.1"]),
    ("a slow animal wins a race against a fast one who takes a nap", ["K11.3"]),
    ("the whole world is flooded and survivors escape in a boat", ["A1021", "A1010"]),
    ("hero escapes from the one-eyed giant's cave clinging under a sheep", ["K603"]),
    ("fools try to carry daylight into a house without windows", ["J2123"]),
    ("a table that covers itself with food on command", ["D1472.1.7", "D1153", "D1472.1.8"]),
    ("the king's barber knows the king has donkey ears and the secret is revealed by reeds", ["F511.2.2", "D1316.5"]),
    ("a ghost comes back to show where money is buried", ["E371", "E545.12"]),
    ("boots that let you cover enormous distances in one step", ["D1521.1"]),
    ("a fisherman marries a woman who was really a seal", ["B651.8", "D327.2", "B601.18"]),
    ("a hat that makes the wearer invisible", ["D1361.15", "K1349.10", "F455.5.3"]),
    ("a dead man returns to help the hero who paid for his burial", ["E341"]),
    ("evil stepmother mistreats her stepdaughter", ["S31"]),
    ("a lion remains grateful to the man who pulled a thorn from its foot", ["B381"]),
    ("princess sleeps for a century until a prince wakes her", ["D1960.3", "D1364.17"]),
    ("tiny boy no bigger than a thumb", ["F535.1"]),
]

PASSAGES = [
    (
        "The wolf ran by the shortest road to the grandmother's house, swallowed the old woman whole, "
        "put on her cap and lay down in her bed. When the little girl came in she cried: 'Oh grandmother, "
        "what big teeth you have!' 'All the better to eat you with!' and he swallowed her too. A hunter passing "
        "by cut open the sleeping wolf's belly and out they both came alive.",
        ["K2011", "F913", "F911.3"],
    ),
    (
        "The miller boasted that his daughter could spin straw into gold, so the king locked her in a room full of straw. "
        "A little man appeared and spun it all into gold in exchange for her necklace, and the third night for her firstborn child. "
        "When he came to fetch the child he said she might keep it if within three days she could guess his name.",
        ["D2183", "H521", "C432.1", "S220", "D475.1.20", "H914"],
    ),
    (
        "As they were led into the forest the boy dropped crumbs of bread along the path, but the birds ate them all and the children "
        "could not find their way home. Deep in the woods they came to a little house made of bread and cake. The old woman who lived there "
        "was a witch who fattened children to eat them, but the girl pushed her into the oven.",
        ["R135.1", "G412.1", "G512.3.2", "S143", "G82", "G526"],
    ),
    (
        "The princess dropped her golden ball into the well and wept, until a frog offered to fetch it if she would let him eat from "
        "her plate and sleep in her bed. Disgusted, she flung him against the wall, and he fell down no longer a frog but a king's son.",
        ["D195", "D712.2", "D700", "S215.1", "D734"],
    ),
    (
        "Jack sold the cow for a handful of beans, and his mother threw them out of the window. In the morning a beanstalk had grown up "
        "into the sky. Jack climbed it and came to the house of a giant who roared 'Fee-fi-fo-fum, I smell the blood of an Englishman!' "
        "Jack stole the hen that laid golden eggs and climbed down, and cut the beanstalk so the giant fell to his death.",
        ["F54.2", "G84", "B103.2.1", "F54", "N421"],
    ),
    (
        "The one-eyed giant asked the hero his name and he answered 'Nobody'. In the night they blinded the giant with a burning stake, and when "
        "the other giants called out who was hurting him, he shouted 'Nobody is hurting me!' In the morning the men escaped clinging under the bellies of the rams.",
        ["K602", "K603", "G511", "G121.1.1", "F531.1.1.1", "F531.1.1.3"],
    ),
    (
        "His wife died of a snakebite and the singer went down to the land of the dead and charmed its king with his lyre. He was allowed "
        "to lead her back to the upper world on one condition: he must not look back at her until they had reached the light. At the last moment he turned.",
        ["F81.1", "C331", "D1275", "F81"],
    ),
    (
        "The king wished that everything he touched would turn to gold. His wish was granted, but when he sat down to eat, his bread and meat "
        "turned to gold in his mouth, and when he embraced his daughter she became a golden statue.",
        ["J2072.1", "D565.1", "J2071"],
    ),
    (
        "Every morning the queen asked her looking-glass who was the fairest in the land. When it answered that her stepdaughter was more "
        "beautiful, she ordered a huntsman to take the girl into the forest and kill her and bring back her heart, but he let her go.",
        ["D1323.1", "D1311.2", "S31", "K512.2", "L55", "L55.1"],
    ),
    (
        "A donkey, a dog, a cat and a rooster, all too old to be of use to their masters, ran away together. At night they came upon a house "
        "where robbers sat feasting. They stood on one another's backs and all cried out at once, and the robbers fled in terror.",
        ["K335.1.4", "K1161", "B296"],
    ),
    (
        "Her husband gave her the keys of the castle and said she might open every door but the little one at the end of the corridor. "
        "Curiosity overcame her; inside lay the bodies of his former wives. She dropped the key in the blood, and the stain would not wash off.",
        ["C611", "C913", "S62.1", "C611.1"],
    ),
    (
        "The old king asked his three daughters how much they loved him. The two eldest flattered him, but the youngest said she loved him as meat "
        "loves salt. Enraged he drove her away; much later he was served a meal without salt and understood her meaning.",
        ["H592.1", "M21", "L52"],
    ),
    (
        "A slave ran away from his master and hid in a cave, where a lion came to him limping. He drew a large thorn from its paw. Years later, "
        "recaptured and thrown to the beasts in the arena, the same lion was released upon him; it lay down at his feet and licked his hands.",
        ["B381"],
    ),
    (
        "The witch shut the girl in a tower in the forest which had neither stairs nor door. When she wanted to get in she called: 'Let down your hair!' "
        "and the girl let her long golden braids fall twenty ells down, and the witch climbed up by them.",
        ["F848.1", "R41.2", "T381"],
    ),
    (
        "Two swindlers came to the city and claimed they could weave cloth so fine that it would be invisible to anyone who was stupid or unfit for "
        "his office. The emperor walked through the streets in his new clothes, and nobody dared admit seeing nothing, until a child cried out that he had nothing on.",
        ["K445"],
    ),
]
