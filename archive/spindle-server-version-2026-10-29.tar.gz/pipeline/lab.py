"""Fast experiments on scoring schemes (readings from the LLM are cached).

    uv run python pipeline/lab.py
"""

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "pipeline"))
from eval_set import DESCRIPTIONS, PASSAGES  # noqa: E402
from spindle.engine import Engine  # noqa: E402
from spindle.reader import Reader, locate  # noqa: E402
from spindle.text import sentences, windows  # noqa: E402

CACHE = ROOT / "data" / "build" / "readings.json"


def readings():
    cache = json.load(open(CACHE)) if CACHE.exists() else {}
    missing = [t for t, _ in PASSAGES if t not in cache]
    if missing:
        r = Reader()
        for t in missing:
            cache[t] = r.read(t)
            print("read", len(cache[t]), "statements", file=sys.stderr)
        json.dump(cache, open(CACHE, "w"), indent=1)
    return cache


def zrows(S):
    mu = S.mean(1, keepdims=True)
    sd = S.std(1, keepdims=True) + 1e-6
    return (S - mu) / sd


def main():
    e = Engine(rerank=False)
    R = readings()
    ids = e.ids
    nkids = np.array([len(e.nodes[m]["children"]) for m in ids], dtype=np.float32)
    depth = np.array([m.count(".") for m in ids], dtype=np.float32)

    # ---------------------------------------------------------- descriptions
    Q = e.encode([q for q, _ in DESCRIPTIONS])
    S = Q @ e.D.T

    def desc_eval(score_fn, name):
        h1 = h10 = mrr = 0
        for qi, (q, gold) in enumerate(DESCRIPTIONS):
            sc = score_fn(qi, q)
            top = [ids[i] for i in np.argsort(-sc)[:10]]
            r = [j for j, m in enumerate(top) if m in gold]
            if r:
                h10 += 1
                h1 += r[0] == 0
                mrr += 1 / (r[0] + 1)
        n = len(DESCRIPTIONS)
        print(f"  desc {name:28s} hit@1 {h1/n:.2f} hit@10 {h10/n:.2f} mrr {mrr/n:.3f}")

    lexes = [e.lexical_scores(q) for q, _ in DESCRIPTIONS]
    desc_eval(lambda qi, q: S[qi], "dense")
    for w in (0.1, 0.25, 0.5):
        desc_eval(lambda qi, q, w=w: e.fuse(S[qi], lexes[qi], w_lex=w), f"rrf w_lex={w}")
    for lam in (0.005, 0.01, 0.02):
        desc_eval(lambda qi, q, lam=lam: S[qi] - lam * np.log1p(nkids), f"dense - {lam}*log(1+kids)")
    for w in (0.002, 0.005):
        desc_eval(lambda qi, q, w=w: S[qi] + w * np.log1p(lexes[qi]), f"dense + {w}*log(1+bm25)")

    # -------------------------------------------------------------- passages
    print()
    data = []
    for text, gold in PASSAGES:
        gold = [g for g in gold if g in e.row]
        sp = sentences(text)
        qs = [("s", text[a:b]) for a, b in sp]
        qs += [("w", text[a:b]) for a, b in windows(sp, 2) if (a, b) not in sp]
        qs += [("r", st["motif"]) for st in R[text] if locate(st.get("quote", ""), text)]
        Qp = e.encode([q for _, q in qs])
        Sp = Qp @ e.D.T
        kinds = np.array([k for k, _ in qs])
        data.append((gold, Sp, kinds, qs))

    def pas_eval(score_fn, name):
        f10 = f20 = tot = 0
        for gold, Sp, kinds, qs in data:
            sc = score_fn(Sp, kinds)
            order = np.argsort(-sc)
            top = [ids[i] for i in order[:20]]
            f20 += sum(1 for g in gold if g in top)
            f10 += sum(1 for g in gold if g in top[:10])
            tot += len(gold)
        print(f"  pass {name:34s} r@10 {f10/tot:.2f} r@20 {f20/tot:.2f}")

    def sel(Sp, kinds, use):
        m = np.isin(kinds, list(use))
        return Sp[m] if m.any() else Sp

    for use in ("s", "sw", "r", "sr", "swr"):
        pas_eval(lambda Sp, k, use=use: sel(Sp, k, use).max(0), f"max raw [{use}]")
        pas_eval(lambda Sp, k, use=use: zrows(sel(Sp, k, use)).max(0), f"max z [{use}]")
    for lam in (0.1, 0.2, 0.4):
        pas_eval(lambda Sp, k, lam=lam: zrows(sel(Sp, k, "swr")).max(0) - lam * np.log1p(nkids), f"max z [swr] - {lam}*log(1+kids)")
    # reader statements get a bonus weight
    for b in (0.3, 0.6, 1.0):
        def f(Sp, k, b=b):
            Z = zrows(Sp)
            Z[k == "r"] += b
            return Z.max(0) - 0.2 * np.log1p(nkids)
        pas_eval(f, f"z with reader bonus {b}")
    # sum of top-2 query evidences
    def top2(Sp, k):
        Z = zrows(Sp)
        Z.sort(0)
        return Z[-1] + 0.3 * Z[-2]
    pas_eval(top2, "z top1 + .3 top2 [swr]")


if __name__ == "__main__" and len(sys.argv) == 1:
    main()


def lab2():
    """Ensembles and lexical evidence for reader statements."""
    from sentence_transformers import SentenceTransformer

    e = Engine(rerank=False)
    R = readings()
    ids = e.ids
    D2 = np.load(ROOT / "data/build/emb/BAAI__bge-m3__context.npy").astype(np.float32)
    m3 = SentenceTransformer("BAAI/bge-m3", device=e.device)

    def enc2(texts):
        return m3.encode(texts, normalize_embeddings=True, convert_to_numpy=True)

    # descriptions
    qs = [q for q, _ in DESCRIPTIONS]
    S1 = e.encode(qs) @ e.D.T
    S2 = enc2(qs) @ D2.T
    for w in (0.0, 0.3, 0.5):
        h10 = mrr = 0
        for qi, (q, gold) in enumerate(DESCRIPTIONS):
            sc = zrows(S1[qi:qi + 1])[0] * (1 - w) + zrows(S2[qi:qi + 1])[0] * w
            top = [ids[i] for i in np.argsort(-sc)[:10]]
            r = [j for j, m in enumerate(top) if m in gold]
            if r:
                h10 += 1
                mrr += 1 / (r[0] + 1)
        print(f"  desc ensemble w_m3={w}: hit@10 {h10/len(qs):.2f} mrr {mrr/len(qs):.3f}")

    data = []
    for text, gold in PASSAGES:
        gold = [g for g in gold if g in e.row]
        sp = sentences(text)
        qs = [("s", text[a:b]) for a, b in sp]
        qs += [("w", text[a:b]) for a, b in windows(sp, 2) if (a, b) not in sp]
        qs += [("r", st["motif"]) for st in R[text] if locate(st.get("quote", ""), text)]
        Z1 = zrows(e.encode([q for _, q in qs]) @ e.D.T)
        Z2 = zrows(enc2([q for _, q in qs]) @ D2.T)
        L = np.stack([e.lexical_scores(q) for _, q in qs])
        L = L / (L.max(1, keepdims=True) + 1e-6)
        kinds = np.array([k for k, _ in qs])
        data.append((gold, Z1, Z2, L, kinds))

    def ev(fn, name):
        f10 = f20 = tot = 0
        for gold, Z1, Z2, L, kinds in data:
            Z = fn(Z1, Z2, L, kinds)
            Z = np.sort(Z, 0)
            sc = Z[-1] + 0.3 * Z[-2]
            top = [ids[i] for i in np.argsort(-sc)[:20]]
            f20 += sum(1 for g in gold if g in top)
            f10 += sum(1 for g in gold if g in top[:10])
            tot += len(gold)
        print(f"  pass {name:40s} r@10 {f10/tot:.2f} r@20 {f20/tot:.2f}")

    ev(lambda Z1, Z2, L, k: Z1, "bge-base")
    ev(lambda Z1, Z2, L, k: Z2, "bge-m3")
    for w in (0.3, 0.5):
        ev(lambda Z1, Z2, L, k, w=w: (1 - w) * Z1 + w * Z2, f"ensemble w={w}")
    for a in (0.5, 1.0, 2.0):
        def f(Z1, Z2, L, k, a=a):
            Z = 0.5 * Z1 + 0.5 * Z2
            Z[k == "r"] += a * L[k == "r"]
            return Z
        ev(f, f"ensemble .5 + reader lexical {a}")
        def g(Z1, Z2, L, k, a=a):
            Z = Z1.copy()
            Z[k == "r"] += a * L[k == "r"]
            return Z
        ev(g, f"bge-base + reader lexical {a}")


if __name__ == "__main__" and len(sys.argv) > 1 and sys.argv[1] == "2":
    lab2()
