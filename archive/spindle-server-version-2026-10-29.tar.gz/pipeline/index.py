"""Build the search index the server loads: embeddings, BM25, and a 2-D map.

    uv run python pipeline/index.py

Output in data/index/: tmi.json, ids.json, emb0.npy, emb1.npy, bm25/, coords.npy, meta.json
"""

import argparse
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from spindle.engine import EMBEDDERS, doc_text, lexical_text  # noqa: E402

BUILD = ROOT / "data" / "build"
OUT = ROOT / "data" / "index"


def embed(model_name, variant, motifs):
    cache = BUILD / "emb" / f"{model_name.replace('/', '__')}__{variant}.npy"
    if cache.exists():
        print(f"reusing {cache.name}", file=sys.stderr)
        return np.load(cache)
    import torch
    from sentence_transformers import SentenceTransformer

    device = "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu")
    model = SentenceTransformer(model_name, device=device)
    texts = [doc_text(m, variant) for m in motifs]
    order = np.argsort([len(t) for t in texts])
    t0 = time.time()
    vecs = model.encode([texts[i] for i in order], batch_size=128, normalize_embeddings=True,
                        show_progress_bar=True, convert_to_numpy=True)
    E = np.empty_like(vecs)
    E[order] = vecs
    E = E.astype(np.float16)
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.save(cache, E)
    print(f"embedded {len(texts)} motifs with {model_name} in {time.time() - t0:.0f}s", file=sys.stderr)
    return E


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-map", action="store_true")
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy(BUILD / "tmi.json", OUT / "tmi.json")
    data = json.load(open(OUT / "tmi.json"))
    motifs = [n for n in data["nodes"] if n["kind"] == "motif"]
    ids = [m["id"] for m in motifs]
    json.dump(ids, open(OUT / "ids.json", "w"))

    specs = []
    for i, (model, variant, prompt, weight) in enumerate(EMBEDDERS):
        E = embed(model, variant, motifs)
        np.save(OUT / f"emb{i}.npy", E.astype(np.float16))
        specs.append({"model": model, "variant": variant, "prompt": prompt, "weight": weight})

    import bm25s
    import Stemmer

    corpus = [lexical_text(m) for m in motifs]
    toks = bm25s.tokenize(corpus, stopwords="en", stemmer=Stemmer.Stemmer("english"), show_progress=False)
    bm = bm25s.BM25()
    bm.index(toks, show_progress=False)
    bm.save(str(OUT / "bm25"))

    if not args.skip_map:
        import umap

        t0 = time.time()
        E = np.load(OUT / "emb0.npy").astype(np.float32)
        reducer = umap.UMAP(n_neighbors=25, min_dist=0.05, metric="cosine", random_state=7)
        xy = reducer.fit_transform(E)
        xy = (xy - xy.min(0)) / (xy.max(0) - xy.min(0))
        np.save(OUT / "coords.npy", xy.astype(np.float32))
        print(f"umap in {time.time() - t0:.0f}s", file=sys.stderr)

    json.dump({"embedders": specs, "count": len(ids)}, open(OUT / "meta.json", "w"), indent=1)
    print(f"index written to {OUT}", file=sys.stderr)


if __name__ == "__main__":
    main()
