# Spindle

A search engine for Stith Thompson's *Motif-Index of Folk-Literature* (revised edition, 1955–58),
and a successor to [MOMFER](https://doi.org/10.1080/0015587X.2015.1006954).

- **Describe** a motif in your own words ("a girl must not look back", "why the bear has a short tail")
  and get the motifs that mean it, however Thompson worded them.
- **Read a tale**: paste a story and Spindle marks, sentence by sentence, the motifs it recognises.
  With a language model available, a *close reading* first restates the tale as Thompson-style motif
  statements and matches those too.
- **Browse** Thompson's tree from A to Z, or wander a **map** on which motifs alike in meaning lie together,
  whatever their letter.
- Every motif page shows its place in the tree, the traditions it is attested in (grouped by region),
  tale types, references with clickable cross-references, subdivisions, and **echoes**: similar motifs
  Thompson filed under other headings.

## Running

```sh
uv sync
uv run python pipeline/parse.py    # ruthenia HTML  -> data/build/motifs.raw.json  (seconds)
uv run python pipeline/build.py    # tree, traditions, cross-refs -> data/build/tmi.json
uv run python pipeline/index.py    # embeddings, BM25, map -> data/index/  (~10 min on an M-series Mac)
uv run spindle                     # http://127.0.0.1:8642
```

The raw sources are in `data/raw/` (the 23 ruthenia.ru pages, the old MOMFER heading index, and the
Internet Archive OCR text, kept for reference). Set `SPINDLE_DEV=1` to reload on code changes.

### Close reading

Close reading uses, in order of preference:

| backend | when | settings |
|---|---|---|
| Claude (Anthropic API) | `ANTHROPIC_API_KEY` is set and `uv sync --extra claude` | `SPINDLE_ANTHROPIC_MODEL` (default `claude-opus-5-5`) |
| Ollama (local) | an Ollama server with the model pulled | `OLLAMA_HOST`, `SPINDLE_OLLAMA_MODEL` (default `gemma3:12b`) |

`SPINDLE_READER=none|ollama|anthropic` forces a choice. With gemma3:12b a close reading takes
about 15–20 s; `gemma3:27b` reads a little more sharply in about 35 s. Without a backend the
button simply does not appear.

## How it works

**Text.** `pipeline/parse.py` re-parses the HTML edition at ruthenia.ru, the fullest digital
transcription of the revised edition. Its italics separate the headline from the explanatory note and
the references, so all three are kept apart. (The old `tmi.json` in the MOMFER repository had lost
many notes and references, and its accented characters.) The ruthenia text had once been decoded
as Windows-1251 instead of Latin-1, turning *Métraux* into *Mйtraux*; that mapping is a bijection and is
reversed character by character. Headlines whose italics stop short ("Fairy wins kiss in game;")
are completed to the end of their sentence, quotes and apostrophes are normalised, and the
handful of entries the transcription garbles beyond repair are patched in `build.py`.

**Tree.** `pipeline/build.py` places every motif under its parent: dotted motifs under their stems,
numbered motifs under the decade headings and ranges of Thompson's synopses (`D100–D199`
*Transformation: man to animal*). For A and B, whose synopses are missing from ruthenia, the
headings come from the old MOMFER index.

**Traditions.** Reference labels ("Irish myth:", "Icel.:", "N. A. Indian (Zuñi):") are normalised into
about 1,100 traditions in 14 regions, so results can be filtered by where a motif is attested.

**Retrieval.** Each motif (headline + note) is embedded by two encoders: `BAAI/bge-base-en-v1.5`
on the motif text and `BAAI/bge-m3` on the motif text plus its branch. For a query, each encoder's
cosine similarities to all 46,220 motifs are turned into z-scores, which makes them comparable, and
averaged (0.6 / 0.4). BM25 adds a small nudge for literal matches. A short query that matches nothing
well is also looked up in the references, which is how "Melusine" finds the Melusine tabu.

**Passages.** Every sentence, every pair of adjacent sentences, every clause and every close-reader
statement is a query. A motif scores its best z-score plus 0.3 × its second best, so motifs attested
in two places rise. A vivid sentence can match dozens of near-identical motifs, so each sentence and
each small branch may contribute only a few. Each motif keeps the span of text that evidences it.

## How well it works

`pipeline/eval_set.py` is a small hand-made benchmark: 30 paraphrased descriptions that avoid
Thompson's wording, and 15 retold tales with the motifs a folklorist would assign. Run it with
`uv run python pipeline/evaluate.py [-v] [--reader]`.

| | |
|---|---|
| descriptions: intended motif ranked first | 0.53 |
| descriptions: intended motif in the top 10 | 0.80 (MRR 0.61) |
| tales: gold motifs in the top 20, text only | 0.31 |
| tales: gold motifs in the top 20, with close reading (gemma3:12b) | 0.46 |

Most misses are near misses, such as the sibling or parent of the intended motif. The benchmark is small,
so treat differences of a few points as noise.

Models compared on the same benchmark (`pipeline/experiment.py`, `pipeline/lab.py`): bge-base, bge-large,
bge-m3, e5-large-v2, mxbai-embed-large, gte-modernbert and Qwen3-Embedding-0.6B. Two findings went against
expectation. Qwen3-Embedding and every cross-encoder reranker tried (bge-reranker-v2-m3) did *worse*:
Thompson's headlines are very short, and these models favour the shortest, most generic ones
("Magic objects."). And combining evidence across sentences mattered more than the choice of model.

## Layout

```
pipeline/   parse.py, build.py, index.py         build the data
            eval_set.py, evaluate.py             benchmark
            experiment.py, lab.py                model and scoring experiments
spindle/    engine.py   retrieval and passage analysis
            reader.py   the close reader (Ollama / Anthropic)
            app.py      FastAPI: /api/search, /api/analyze, /api/read, /api/motif/{id}, /api/tree, /api/map …
            text.py     sentence and clause segmentation with offsets
web/        index.html, static/app.js, static/app.css, static/samples.js   (no build step)
            art/        papercut illustrations (generated by tools/artgen.py)
tools/      artgen.py   regenerates the SVG illustrations
            shoot.py    screenshots of a running instance (Playwright + system Chrome)
```

## Search syntax

| query | does |
|---|---|
| `a girl must not look back` | search by meaning |
| `D1960.3` | open a motif (and its subdivisions) |
| `dragon in:B` | within a branch, section or motif |
| `trickster culture:Irish` | only motifs attested in a tradition |
| `ogre region:"South Asia"` | only motifs attested in a region |
| `type:510` | motifs referring to a tale type (510, 510A, 510B …) |
