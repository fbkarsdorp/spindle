"""Small text utilities: sentence segmentation with character offsets."""

import re

ABBREVIATIONS = {
    "mr", "mrs", "ms", "dr", "st", "mt", "no", "vs", "etc", "e.g", "i.e", "cf", "viz", "ca", "jr", "sr", "fig", "vol",
}

# a sentence ends at . ! ? (possibly followed by closing quotes/brackets) + whitespace
_END = re.compile(r"[.!?…]+[\"'”’)\]]*(?=\s+|$)")


def sentences(text: str):
    """Split text into sentences, returning (start, end) character offsets.

    Deliberately simple and predictable: dialogue stays attached to its
    sentence when the quote closes mid-sentence, and common abbreviations do
    not end a sentence.
    """
    spans = []
    start = 0
    n = len(text)
    # skip leading whitespace
    while start < n and text[start].isspace():
        start += 1
    for m in _END.finditer(text):
        end = m.end()
        word = re.search(r"([A-Za-z.]+)[.!?…]*[\"'”’)\]]*$", text[start:end])
        if word and word.group(1).lower().rstrip(".") in ABBREVIATIONS:
            continue
        # don't split if the next char starts lowercase (e.g. '"Help!" she cried')
        rest = text[end:].lstrip()
        if rest and rest[0].islower():
            continue
        if text[start:end].strip():
            spans.append((start, end))
        start = end
        while start < n and text[start].isspace():
            start += 1
    if start < n and text[start:].strip():
        spans.append((start, n))
    # paragraphs: also split on blank lines inside a span
    out = []
    for s, e in spans:
        chunk = text[s:e]
        offset = s
        for part in re.split(r"(\n\s*\n)", chunk):
            if part.strip() and not re.fullmatch(r"\n\s*\n", part):
                lead = len(part) - len(part.lstrip())
                out.append((offset + lead, offset + len(part.rstrip())))
            offset += len(part)
    return out


def windows(spans, size=2):
    """Overlapping windows of consecutive sentences, as (start, end) offsets."""
    if len(spans) <= size:
        return [(spans[0][0], spans[-1][1])] if spans else []
    return [(spans[i][0], spans[i + size - 1][1]) for i in range(len(spans) - size + 1)]


TOKEN = re.compile(r"[a-z0-9]+(?:['’][a-z]+)?")


def tokens(text: str):
    return TOKEN.findall(text.lower())


_CLAUSE = re.compile(r"[;:]\s+|,\s+(?=(?:and|but|then|so|when|while|until|where|who|which)\b)|\s+(?=(?:and then|but)\b)")


def clauses(text: str, spans, min_words=4):
    """Split sentences into clauses (offsets), keeping only clauses of some substance."""
    out = []
    for a, b in spans:
        chunk = text[a:b]
        pos = 0
        parts = []
        for m in _CLAUSE.finditer(chunk):
            parts.append((pos, m.start()))
            pos = m.end()
        parts.append((pos, len(chunk)))
        if len(parts) < 2:
            continue
        for x, y in parts:
            piece = chunk[x:y].strip()
            if len(piece.split()) >= min_words:
                lead = len(chunk[x:y]) - len(chunk[x:y].lstrip())
                out.append((a + x + lead, a + x + lead + len(piece)))
    return out
