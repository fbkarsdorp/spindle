"""The 'close reader': a language model that restates a passage as abstract,
Thompson-style motif statements, each tied to a verbatim quote.

Those statements are far closer in register to the Motif-Index than raw story
prose, so retrieving with them is much more accurate. Two backends:

  * Ollama (local; default model gemma3:12b) — used when an Ollama server is reachable
  * Anthropic API — used when ANTHROPIC_API_KEY is set and SPINDLE_READER=anthropic
"""

from __future__ import annotations

import json
import logging
import os
import re
import urllib.error
import urllib.request

log = logging.getLogger("spindle")

SYSTEM = """You are an expert folklorist who knows Stith Thompson's Motif-Index of Folk-Literature by heart.
Read the passage and name every narrative motif in it, as index entries.

Thompson's headlines are CONCRETE: they keep the specific creature, object, act and relationship.
Good: "Wolf poses as grandmother and kills child." "Crumb trail eaten by birds." "Ogre's gingerbread house lures child."
"Ogre burned in his own oven." "Transformation: man to frog." "Disenchantment by throwing against wall."
"Plant grows to sky." "Escape under ram's belly." "Guessing name of supernatural creature gives power over him."
"Forbidden chamber." "Bloody key as sign of disobedience." "Slipper test." "Cruel stepmother." "Magic mirror."
"Tasks assigned because of mother's foolish boasting." "Victims rescued from swallower's belly."
Bad (too vague): "Animal disguises itself." "Lost object." "Supernatural helper." "Threat." "Disgust."

Rules:
- One entry per motif; a single sentence of the passage may contain several motifs.
- Name the creature or object (wolf, frog, giant, witch, spindle, mirror), never just "animal", "being" or "object".
- Use the conventional names folklorists use for well-known episodes when they apply.
- Cover characters (e.g. "Cruel stepmother.", "One-eyed giant."), magic, tabus, tests, deceptions, rescues, rewards and punishments.
- For each motif quote the shortest span of the passage that attests it, copied verbatim.
- List them in the order they occur; usually 5 to 15."""

SCHEMA = {
    "type": "object",
    "properties": {
        "motifs": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"motif": {"type": "string"}, "quote": {"type": "string"}},
                "required": ["motif", "quote"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["motifs"],
    "additionalProperties": False,
}

OLLAMA_URL = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
OLLAMA_MODEL = os.environ.get("SPINDLE_OLLAMA_MODEL", "gemma3:12b")
ANTHROPIC_MODEL = os.environ.get("SPINDLE_ANTHROPIC_MODEL", "claude-opus-5-5")


class Reader:
    def __init__(self):
        self.backend = None
        self.model = None
        # SPINDLE_READER: auto (default) | anthropic | ollama | none
        pref = os.environ.get("SPINDLE_READER", "auto").lower()
        if pref in ("auto", "anthropic") and os.environ.get("ANTHROPIC_API_KEY"):
            self.backend, self.model = "anthropic", ANTHROPIC_MODEL
        elif pref in ("auto", "ollama") and self._ollama_has_model():
            self.backend, self.model = "ollama", OLLAMA_MODEL
        log.info("reader backend: %s (%s)", self.backend, self.model)

    @property
    def available(self):
        return self.backend is not None

    def _ollama_has_model(self):
        try:
            with urllib.request.urlopen(f"{OLLAMA_URL}/api/tags", timeout=1.5) as r:
                tags = json.load(r)
            names = {m["name"] for m in tags.get("models", [])}
            return OLLAMA_MODEL in names or f"{OLLAMA_MODEL}:latest" in names
        except (urllib.error.URLError, OSError, ValueError):
            return False

    def read(self, text: str, timeout: float = 120):
        """Return a list of {"motif", "quote"} dicts."""
        if self.backend == "ollama":
            raw = self._ollama(text, timeout)
        elif self.backend == "anthropic":
            raw = self._anthropic(text)
        else:
            return []
        out = []
        for m in raw:
            stmt = re.sub(r"\s+", " ", str(m.get("motif", ""))).strip()
            quote = re.sub(r"\s+", " ", str(m.get("quote", ""))).strip()
            if stmt:
                out.append({"motif": stmt, "quote": quote})
        return out

    def _ollama(self, text, timeout):
        body = {
            "model": self.model,
            "stream": False,
            "format": SCHEMA,
            "options": {"temperature": 0, "num_ctx": 8192},
            "keep_alive": "30m",
            "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": text}],
        }
        req = urllib.request.Request(f"{OLLAMA_URL}/api/chat", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            resp = json.load(r)
        return json.loads(resp["message"]["content"]).get("motifs", [])

    def _anthropic(self, text):
        import anthropic

        client = anthropic.Anthropic()
        response = client.beta.messages.create(
            model=self.model,
            max_tokens=16000,
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            output_config={"effort": "low", "format": {"type": "json_schema", "schema": SCHEMA}},
            system=SYSTEM,
            messages=[{"role": "user", "content": text}],
        )
        if response.stop_reason == "refusal":
            log.warning("reader refused: %s", response.stop_details)
            return []
        body = next((b.text for b in response.content if b.type == "text"), "{}")
        return json.loads(body).get("motifs", [])


def locate(quote: str, text: str):
    """Find a (possibly slightly paraphrased) quote in the text; return (start, end) or None."""
    if not quote:
        return None
    i = text.find(quote)
    if i >= 0:
        return i, i + len(quote)
    low = text.lower()
    q = quote.lower().strip(" .,'\"“”‘’…")
    i = low.find(q)
    if i >= 0:
        return i, i + len(q)
    # fall back to the longest run of words that does occur
    words = re.findall(r"\w+", q)
    best = None
    for size in range(min(len(words), 8), 1, -1):
        for j in range(len(words) - size + 1):
            pat = r"\W+".join(re.escape(w) for w in words[j:j + size])
            m = re.search(pat, low)
            if m:
                best = (m.start(), m.end())
                break
        if best:
            break
    return best
