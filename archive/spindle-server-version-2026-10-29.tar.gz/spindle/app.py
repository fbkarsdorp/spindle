"""HTTP API and static front-end for Spindle.

    uv run spindle            # or: uv run uvicorn spindle.app:app
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import random
from contextlib import asynccontextmanager
from functools import lru_cache
from pathlib import Path

import numpy as np
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .engine import Engine, Filters
from .reader import Reader

log = logging.getLogger("spindle")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
for noisy in ("httpx", "huggingface_hub", "sentence_transformers"):
    logging.getLogger(noisy).setLevel(logging.WARNING)

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"

engine: Engine | None = None
reader: Reader | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global engine, reader
    engine = Engine()
    await asyncio.to_thread(engine.warmup)
    reader = Reader()
    log.info("ready: %d motifs", engine.n)
    yield


app = FastAPI(title="Spindle", lifespan=lifespan)


# ---------------------------------------------------------------- serialise


def brief(mid: str):
    """The compact shape used in lists."""
    n = engine.nodes[mid]
    out = {"id": mid, "kind": n["kind"], "title": n["title"]}
    if n["kind"] == "motif":
        out["note"] = n.get("note", "")
        out["cultures"] = n.get("cultures", [])[:8]
        out["n_cultures"] = len(n.get("cultures", []))
        out["path"] = [{"id": p, "title": engine.nodes[p]["title"]} for p in n["path"][-3:]]
        out["letter"] = mid[0]
        out["n_children"] = len(n["children"])
    return out


def full(mid: str):
    n = engine.nodes[mid]
    out = {
        "id": mid,
        "kind": n["kind"],
        "title": n["title"],
        "path": [{"id": p, "title": engine.nodes[p]["title"], "kind": engine.nodes[p]["kind"]} for p in n["path"]],
        "children": [brief_child(c) for c in n["children"]],
    }
    if n["kind"] == "motif":
        out.update({
            "note": n.get("note", ""),
            "refs": n.get("refs", ""),
            "cultures": n.get("cultures", []),
            "regions": n.get("regions", []),
            "types": n.get("types", []),
            "cf": [brief(c) for c in n.get("cf", [])],
            "cited_by": [brief(c) for c in n.get("cited_by", [])],
            "alt_titles": n.get("alt_titles", []),
            "letter": mid[0],
            "category": engine.categories[mid[0]],
        })
        parent = n["parent"]
        if parent:
            sibs = [s for s in engine.nodes[parent]["children"]]
            i = sibs.index(mid)
            out["prev"] = brief_child(sibs[i - 1]) if i > 0 else None
            out["next"] = brief_child(sibs[i + 1]) if i + 1 < len(sibs) else None
            out["parent"] = brief_child(parent)
        out["echoes"] = [dict(brief(e), sim=round(s, 3)) for e, s in engine.neighbours(mid, k=8)]
        out["kin"] = [dict(brief(e), sim=round(s, 3)) for e, s in engine.neighbours(mid, k=6, other_branches=False)
                      if e not in n["children"] and e != n["parent"]][:5]
    else:
        out["letter"] = mid[0]
        if n["kind"] == "section":
            out["range"] = mid
    return out


def brief_child(cid: str):
    c = engine.nodes[cid]
    return {"id": cid, "kind": c["kind"], "title": c["title"], "n_children": len(c["children"]),
            "has_note": bool(c.get("note"))}


# --------------------------------------------------------------------- API


def make_filters(culture, region, within, type_):
    f = Filters()
    f.cultures = [c for c in culture if c]
    f.regions = [r for r in region if r]
    f.within = [w for w in within if w]
    f.types = [t for t in type_ if t]
    return f


@app.get("/api/search")
async def search(q: str = "", k: int = Query(40, le=200), culture: list[str] = Query([]),
                 region: list[str] = Query([]), within: list[str] = Query([], alias="in"),
                 type: list[str] = Query([])):
    f = make_filters(culture, region, within, type)
    res = await asyncio.to_thread(engine.search, q, k, f)
    items = [dict(brief(mid), score=round(score, 4), via=via) for mid, score, via in res]
    return {"query": q, "results": items, "facets": facets_for([i["id"] for i in items])}


def facets_for(ids):
    cats, regs = {}, {}
    for mid in ids:
        n = engine.nodes[mid]
        cats[mid[0]] = cats.get(mid[0], 0) + 1
        for r in n.get("regions", []):
            regs[r] = regs.get(r, 0) + 1
    return {"categories": cats, "regions": regs}


class AnalyzeIn(BaseModel):
    text: str = Field(..., max_length=20000)
    k: int = 24
    culture: list[str] = []
    region: list[str] = []
    within: list[str] = []


def _analyze_payload(text, res):
    motifs = []
    for m in res["motifs"]:
        b = brief(m["id"])
        b.update({k: v for k, v in m.items() if k != "id"})
        motifs.append(b)
    return {"sentences": res["sentences"], "motifs": motifs}


@app.post("/api/analyze")
async def analyze(body: AnalyzeIn):
    text = body.text.strip()
    if not text:
        return {"sentences": [], "motifs": []}
    f = make_filters(body.culture, body.region, body.within, [])
    res = await asyncio.to_thread(engine.analyze, text, body.k, f if not f.empty() else None)
    return _analyze_payload(text, res)


@app.post("/api/read")
async def read(body: AnalyzeIn):
    """Close reading: stream the reader's statements, then the refined motif list (NDJSON)."""
    text = body.text.strip()
    if not reader or not reader.available:
        raise HTTPException(503, "No language model is available for close reading.")
    f = make_filters(body.culture, body.region, body.within, [])

    async def gen():
        yield json.dumps({"event": "start", "backend": reader.backend, "model": reader.model}) + "\n"
        try:
            statements = await asyncio.to_thread(reader.read, text)
        except Exception as e:  # noqa: BLE001 - report any backend failure to the client
            log.exception("reader failed")
            yield json.dumps({"event": "error", "message": str(e)}) + "\n"
            return
        yield json.dumps({"event": "statements", "statements": statements}) + "\n"
        res = await asyncio.to_thread(engine.analyze, text, body.k, f if not f.empty() else None, statements)
        yield json.dumps({"event": "motifs", **_analyze_payload(text, res)}) + "\n"

    return StreamingResponse(gen(), media_type="application/x-ndjson")


@app.get("/api/motif/{mid}")
async def motif(mid: str):
    if mid not in engine.nodes:
        alt = engine.lookup_id(mid)
        if not alt:
            raise HTTPException(404, f"No motif {mid}")
        mid = alt
    return await asyncio.to_thread(full, mid)


@app.get("/api/tree")
async def tree():
    """Top of the index: the 23 categories with their sections."""
    out = []
    for letter, name in engine.categories.items():
        n = engine.nodes[letter]
        out.append({
            "id": letter, "title": name,
            "count": sum(1 for mid in engine.ids if mid[0] == letter),
            "children": [brief_child(c) for c in n["children"]],
        })
    return out


@app.get("/api/meta")
async def meta():
    return {
        "count": engine.n,
        "categories": engine.categories,
        "regions": engine.regions,
        "cultures": engine.cultures[:400],
        "n_cultures": len(engine.cultures),
        "reader": {"available": bool(reader and reader.available), "backend": reader.backend if reader else None,
                   "model": reader.model if reader else None},
        "models": [e["model"] for e in engine.embedders],
    }


@lru_cache(maxsize=1)
def _notable():
    # motifs that make good openings: a note, several cultures, a tidy headline
    return [mid for mid in engine.ids
            if engine.nodes[mid].get("note") and len(engine.nodes[mid].get("cultures", [])) >= 2
            and len(engine.nodes[mid]["title"]) < 90]


@app.get("/api/random")
async def random_motif(seed: int | None = None):
    pool = _notable()
    rnd = random.Random(seed)
    return brief(rnd.choice(pool))


@app.get("/api/map")
async def map_points():
    """All motifs as a compact binary: per motif uint16 x, uint16 y, uint8 category index."""
    if engine.coords is None:
        raise HTTPException(404, "map not built")
    return Response(_map_blob(), media_type="application/octet-stream",
                    headers={"Cache-Control": "public, max-age=86400"})


@lru_cache(maxsize=1)
def _map_blob():
    letters = list(engine.categories)
    xy = np.clip(engine.coords * 65535, 0, 65535).astype("<u2")
    cat = np.array([letters.index(mid[0]) for mid in engine.ids], dtype="u1")
    rec = np.zeros(engine.n, dtype=[("x", "<u2"), ("y", "<u2"), ("c", "u1")])
    rec["x"], rec["y"], rec["c"] = xy[:, 0], xy[:, 1], cat
    return rec.tobytes()


@app.get("/api/ids")
async def ids():
    """Row order of the map blob, with titles, for hover labels."""
    return JSONResponse([[mid, engine.nodes[mid]["title"]] for mid in engine.ids],
                        headers={"Cache-Control": "public, max-age=86400"})


# ------------------------------------------------------------------ static

app.mount("/art", StaticFiles(directory=WEB / "art"), name="art")
app.mount("/static", StaticFiles(directory=WEB / "static"), name="static")


@app.get("/{path:path}")
async def spa(path: str):
    # client-side routes (/motif/D113.1.1, /browse/D, /read, /map ...) all serve the app shell
    return FileResponse(WEB / "index.html")


def main():
    import uvicorn

    uvicorn.run("spindle.app:app", host=os.environ.get("HOST", "127.0.0.1"),
                port=int(os.environ.get("PORT", "8642")), reload=os.environ.get("SPINDLE_DEV") == "1",
                reload_dirs=[str(ROOT / "spindle")])
