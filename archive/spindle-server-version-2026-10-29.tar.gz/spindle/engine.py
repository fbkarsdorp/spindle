"""The search engine.

Retrieval is dense: every motif (headline + explanatory note) is embedded by two
complementary sentence encoders, and a query is scored against both. Each
encoder's similarities are standardised per query (z-scores), which makes them
comparable across encoders and across the many sub-queries a passage produces,
and the two are averaged. BM25 adds a small lexical nudge, mostly useful for
names and rare words.

For a passage, every sentence, every pair of adjacent sentences and, when a
language model is available, every motif statement of the close reader is a
query. A motif's score is its best z-score plus a fraction of its second best:
motifs attested in more than one place rise.
"""

from __future__ import annotations

import json
import logging
import re
import threading
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .text import clauses, sentences, windows

log = logging.getLogger("spindle")

ROOT = Path(__file__).resolve().parent.parent
INDEX_DIR = ROOT / "data" / "index"

# (model, document representation, query prompt, weight)
EMBEDDERS = [
    ("BAAI/bge-base-en-v1.5", "note", "Represent this sentence for searching relevant passages: ", 0.6),
    ("BAAI/bge-m3", "context", "", 0.4),
]

ID_RE = re.compile(r"^\s*([A-Za-z])\s?(\d+(?:\.\d+)*)\.?\s*$")
FILTER_RE = re.compile(r'\b(culture|region|in|type):(?:"([^"]+)"|(\S+))', re.I)


def doc_text(m: dict, variant: str = "note") -> str:
    """The text of a motif as an encoder sees it."""
    t = m["title"] + (" " + m["note"] if m.get("note") else "")
    if variant == "context":
        where = m["category"] + (" › " + m["context"] if m.get("context") else "")
        return f"{t}\n({where})"
    return t


def lexical_text(m: dict) -> str:
    """What BM25 sees: headline, note and the titles of the branch it sits in."""
    return " ".join(x for x in (m["title"], m.get("note", ""), m.get("context", "")) if x)


@dataclass
class Filters:
    cultures: list[str] = field(default_factory=list)
    regions: list[str] = field(default_factory=list)
    within: list[str] = field(default_factory=list)  # node ids: letters, sections, motifs
    types: list[str] = field(default_factory=list)

    def empty(self):
        return not (self.cultures or self.regions or self.within or self.types)

    def merge(self, other: "Filters"):
        self.cultures += other.cultures
        self.regions += other.regions
        self.within += other.within
        self.types += other.types
        return self


def parse_query(q: str):
    """Pull `culture:Irish region:"South Asia" in:D type:300` filters out of a query."""
    f = Filters()
    for m in FILTER_RE.finditer(q):
        key, val = m.group(1).lower(), (m.group(2) or m.group(3))
        if key == "culture":
            f.cultures.append(val)
        elif key == "region":
            f.regions.append(val)
        elif key == "in":
            f.within.append(val.upper() if len(val) == 1 else val)
        elif key == "type":
            f.types.append(val.upper())
    rest = FILTER_RE.sub(" ", q).strip()
    return re.sub(r"\s+", " ", rest), f


def fold(text: str) -> str:
    """Lower-case and strip accents: 'Mélusine' -> 'melusine'."""
    return "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c)).lower()


def zrows(S: np.ndarray) -> np.ndarray:
    mu = S.mean(1, keepdims=True)
    sd = S.std(1, keepdims=True) + 1e-6
    return (S - mu) / sd


def confidence(z, centre=4.9, scale=0.7):
    """Map an ensemble z-score to a 0–1 confidence for display. Calibrated on
    the benchmark: for a description, the intended motif typically scores
    z ≈ 5.3 and the tenth result z ≈ 4.3; a passage's combined scores run higher."""
    return 1.0 / (1.0 + np.exp(-(np.asarray(z) - centre) / scale))


class Engine:
    def __init__(self, index_dir: Path = INDEX_DIR, device: str | None = None):
        self.index_dir = Path(index_dir)
        meta = json.load(open(self.index_dir / "meta.json"))
        self.embedders = meta["embedders"]
        data = json.load(open(self.index_dir / "tmi.json"))
        self.categories = data["categories"]
        self.nodes = {n["id"]: n for n in data["nodes"]}
        self.cultures = data["cultures"]
        self.regions = data["regions"]
        self.types = data["types"]
        self.ids = json.load(open(self.index_dir / "ids.json"))
        self.row = {mid: i for i, mid in enumerate(self.ids)}
        self.n = len(self.ids)
        self.matrices = [np.load(self.index_dir / f"emb{i}.npy").astype(np.float32)
                         for i in range(len(self.embedders))]
        self.D = self.matrices[0]  # used for neighbours
        self.coords = np.load(self.index_dir / "coords.npy") if (self.index_dir / "coords.npy").exists() else None

        cul, reg, typ = {}, {}, {}
        for i, mid in enumerate(self.ids):
            m = self.nodes[mid]
            for c in m.get("cultures", []):
                cul.setdefault(c.lower(), []).append(i)
            for r in m.get("regions", []):
                reg.setdefault(r.lower(), []).append(i)
            for t in m.get("types", []):
                typ.setdefault(t.upper(), []).append(i)
        self._culture_rows = {k: np.array(v) for k, v in cul.items()}
        self._region_rows = {k: np.array(v) for k, v in reg.items()}
        self._type_rows = {k: np.array(v) for k, v in typ.items()}
        self._paths = [set(self.nodes[mid]["path"]) for mid in self.ids]
        self._refs = [fold(self.nodes[mid].get("refs", "")) for mid in self.ids]

        self._device = device
        self._encoders = None
        self._bm25 = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ models

    @property
    def device(self):
        if self._device is None:
            import torch

            self._device = "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu")
        return self._device

    @property
    def encoders(self):
        if self._encoders is None:
            from sentence_transformers import SentenceTransformer

            self._encoders = []
            for e in self.embedders:
                log.info("loading encoder %s on %s", e["model"], self.device)
                self._encoders.append(SentenceTransformer(e["model"], device=self.device))
        return self._encoders

    @property
    def bm25(self):
        if self._bm25 is None:
            import bm25s
            import Stemmer

            self._stemmer = Stemmer.Stemmer("english")
            self._bm25 = bm25s.BM25.load(str(self.index_dir / "bm25"))
        return self._bm25

    def warmup(self):
        self.zscores(["warm up"])
        self.lexical_scores("warm up")

    def zscores(self, texts: list[str]) -> np.ndarray:
        """Ensemble z-scores of every motif for every text: shape (len(texts), n)."""
        with self._lock:
            Z = np.zeros((len(texts), self.n), dtype=np.float32)
            for enc, spec, D in zip(self.encoders, self.embedders, self.matrices):
                Q = enc.encode([spec["prompt"] + t for t in texts], normalize_embeddings=True,
                               convert_to_numpy=True, batch_size=32)
                Z += spec["weight"] * zrows(Q @ D.T)
        return Z

    def lexical_scores(self, query: str) -> np.ndarray:
        import bm25s

        bm = self.bm25
        toks = bm25s.tokenize([query], stopwords="en", stemmer=self._stemmer, return_ids=False, show_progress=False)[0]
        toks = [t for t in toks if t in bm.vocab_dict]
        if not toks:
            return np.zeros(self.n, dtype=np.float32)
        return bm.get_scores(toks).astype(np.float32)

    # ----------------------------------------------------------------- filters

    def filter_mask(self, f: Filters | None):
        if f is None or f.empty():
            return None
        mask = np.ones(self.n, dtype=bool)

        def rows_for(table, keys):
            sel = np.zeros(self.n, dtype=bool)
            for k in keys:
                k = k.lower()
                for name, rows in table.items():
                    if name == k or name.startswith(k + " ") or name.startswith(k + " ("):
                        sel[rows] = True
            return sel

        if f.cultures:
            mask &= rows_for(self._culture_rows, f.cultures)
        if f.regions:
            mask &= rows_for(self._region_rows, f.regions)
        if f.types:
            sel = np.zeros(self.n, dtype=bool)
            for t in f.types:
                # 'type:510' also covers 510A, 510B, 510*
                for key, rows in self._type_rows.items():
                    if key == t or (key.startswith(t) and not key[len(t):][:1].isdigit()):
                        sel[rows] = True
            mask &= sel
        if f.within:
            want = set(f.within)
            sel = np.fromiter((mid in want or bool(want & p) for mid, p in zip(self.ids, self._paths)),
                              dtype=bool, count=self.n)
            mask &= sel
        return mask

    # ------------------------------------------------------------------ search

    def lookup_id(self, q: str):
        m = ID_RE.match(q)
        if not m:
            return None
        mid = m.group(1).upper() + m.group(2)
        return mid if mid in self.nodes else None

    def search(self, query: str, k: int = 30, filters: Filters | None = None):
        """Returns a list of (motif_id, score, via): score is a 0–1 confidence,
        via says how the motif was found (meaning, id, child, filter, refs)."""
        query, parsed = parse_query(query)
        f = (filters or Filters()).merge(parsed)
        mask = self.filter_mask(f)

        exact = self.lookup_id(query) if query else None
        if exact:
            node = self.nodes[exact]
            out = [(exact, 1.0, "id")] if node["kind"] == "motif" else []
            out += [(c, 0.9, "child") for c in node["children"] if self.nodes[c]["kind"] == "motif"]
            return out[:k]
        if not query:
            if mask is None:
                return []
            return [(self.ids[i], 0.0, "filter") for i in np.flatnonzero(mask)[:k]]

        z = self.zscores([query])[0]
        lex = self.lexical_scores(query)
        if lex.max() > 0:
            # a nudge for literal matches; stronger for short, name-like queries
            w = 1.5 if len(query.split()) <= 2 else 0.6
            z = z + w * lex / lex.max()
        if mask is not None:
            z = np.where(mask, z, -np.inf)
        top = np.argpartition(-z, min(k, self.n - 1))[:k]
        top = top[np.argsort(-z[top])]
        out = [(self.ids[i], float(confidence(z[i]))) for i in top if np.isfinite(z[i])]
        # A name that is in no headline may still be in the references
        # ("Melusine" only occurs in Köhler's Melusinensage): look there too.
        if len(query.split()) <= 3 and (not out or out[0][1] < 0.5) and len(query) >= 4:
            needle = fold(query)
            hits = [i for i, r in enumerate(self._refs) if needle in r and (mask is None or mask[i])]
            if hits:
                hits.sort(key=lambda i: (-self._refs[i].count(needle), -z[i]))
                ref_hits = [(self.ids[i], 0.5, "refs") for i in hits[:k]]
                seen = {h[0] for h in ref_hits}
                out = ref_hits + [o for o in out if o[0] not in seen]
        return [o if len(o) == 3 else (o[0], o[1], "meaning") for o in out[:k]]

    # ---------------------------------------------------------------- passages

    def analyze(self, text: str, k: int = 24, filters: Filters | None = None, statements=None):
        """Find motifs in a passage.

        Returns {"sentences": [[start, end], ...], "motifs": [{id, score, span, via, reading?}, ...]}
        where span is the character range of the text that best attests the motif.
        """
        from .reader import locate

        spans = sentences(text)
        if not spans:
            return {"sentences": [], "motifs": []}
        queries = [(text[a:b], (a, b), "sentence") for a, b in spans]
        queries += [(text[a:b], (a, b), "window") for a, b in windows(spans, 2) if (a, b) not in spans]
        queries += [(text[a:b], (a, b), "clause") for a, b in clauses(text, spans)]
        for st in statements or []:
            loc = locate(st.get("quote", ""), text)
            if loc is not None and st.get("motif"):
                queries.append((st["motif"], loc, "reader"))

        Z = self.zscores([q for q, _, _ in queries])
        mask = self.filter_mask(filters)
        if mask is not None:
            Z[:, ~mask] = -np.inf

        if len(queries) > 1:
            part = np.partition(Z, len(queries) - 2, axis=0)
            first, second = part[-1], part[-2]
            score = first + 0.3 * np.maximum(second, 0)
        else:
            score = Z[0]
        best_q = Z.argmax(0)

        # Selection with diversity: a vivid sentence can match dozens of closely
        # related motifs (every kind of giant's eye); keep the best few per
        # sentence and per small branch so the whole tale is covered.
        def sentence_of(a, b):
            for si, (x, y) in enumerate(spans):
                if a < y and b > x:
                    return si
            return -1

        order = np.argsort(-score)
        out, per_branch, per_sentence = [], {}, {}
        cap_sentence = max(2, min(4, k // max(1, len(spans))))
        for i in order[: k * 40]:
            if not np.isfinite(score[i]):
                break
            mid = self.ids[i]
            path = self.nodes[mid]["path"]
            branch = path[-2] if len(path) >= 2 else path[-1]
            if per_branch.get(branch, 0) >= 2:
                continue
            q, (a, b), kind = queries[best_q[i]]
            if kind == "window":
                inner = [si for si in range(len(spans)) if spans[si][0] >= a and spans[si][1] <= b]
                if inner:
                    a, b = spans[max(inner, key=lambda si: Z[si, i])]
            si = sentence_of(a, b)
            if per_sentence.get(si, 0) >= cap_sentence:
                continue
            per_branch[branch] = per_branch.get(branch, 0) + 1
            per_sentence[si] = per_sentence.get(si, 0) + 1
            item = {"id": mid, "score": round(float(confidence(score[i], 7.0, 1.0)), 4), "span": [a, b], "via": kind}
            if kind == "reader":
                item["reading"] = q
            out.append(item)
            if len(out) >= k:
                break
        return {"sentences": [list(x) for x in spans], "motifs": out}

    # ------------------------------------------------------------- neighbours

    def neighbours(self, mid: str, k: int = 12, other_branches: bool = True):
        """Semantically similar motifs; with other_branches, only those in a
        different second-level section (Thompson's own 'echoes')."""
        if mid not in self.row:
            return []
        sims = self.D @ self.D[self.row[mid]]
        node = self.nodes[mid]
        branch = node["path"][1] if len(node["path"]) > 1 else None
        out = []
        for i in np.argsort(-sims)[:400]:
            other = self.ids[i]
            if other == mid:
                continue
            if other_branches:
                p = self.nodes[other]["path"]
                if (p[1] if len(p) > 1 else None) == branch:
                    continue
            out.append((other, float(sims[i])))
            if len(out) >= k:
                break
        return out
